import { motion } from 'framer-motion';

interface TestimonialCardProps {
  name: string;
  rating: number;
  text: string;
  initial: string;
  bgColorClass: string;
}

export default function TestimonialCard({ name, rating, text, initial, bgColorClass }: TestimonialCardProps) {
  // Generate star rating
  const stars = [];
  for (let i = 1; i <= 5; i++) {
    if (i <= rating) {
      stars.push(<i key={i} className="fas fa-star"></i>);
    } else if (i - 0.5 <= rating) {
      stars.push(<i key={i} className="fas fa-star-half-alt"></i>);
    } else {
      stars.push(<i key={i} className="far fa-star"></i>);
    }
  }

  return (
    <motion.div 
      className="bg-neutral-50 rounded-xl p-8 shadow-md"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="flex items-center space-x-3 mb-4">
        <div className={`w-12 h-12 ${bgColorClass} text-white rounded-full flex items-center justify-center font-bold`}>
          {initial}
        </div>
        <div>
          <h4 className="font-semibold">{name}</h4>
          <div className="flex text-yellow-400">
            {stars}
          </div>
        </div>
      </div>
      <p className="text-neutral-700">{text}</p>
    </motion.div>
  );
}
