import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/auth-context';

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [location] = useLocation();
  const { user, logout } = useAuth();

  // Close mobile menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const menu = document.getElementById('mobile-menu');
      const button = document.getElementById('mobile-menu-button');
      
      if (
        menu && 
        button && 
        !menu.contains(event.target as Node) && 
        !button.contains(event.target as Node) && 
        mobileMenuOpen
      ) {
        setMobileMenuOpen(false);
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, [mobileMenuOpen]);

  // Close mobile menu on location change
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <Link href="/" className="flex items-center">
          <div className="text-primary text-3xl font-heading font-bold">
            BUY<span className="text-[#FF6B35]">MORE</span>
          </div>
        </Link>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <Link href="/" className={`font-medium ${isActive('/') ? 'text-primary' : 'text-neutral-700 hover:text-primary'} transition-colors`}>
            Home
          </Link>
          <Link href="/stores" className={`font-medium ${isActive('/stores') ? 'text-primary' : 'text-neutral-700 hover:text-primary'} transition-colors`}>
            Find Stores
          </Link>
          <Link href="/#how-it-works" className="font-medium text-neutral-700 hover:text-primary transition-colors">
            How It Works
          </Link>
          <Link href="/about" className={`font-medium ${isActive('/about') ? 'text-primary' : 'text-neutral-700 hover:text-primary'} transition-colors`}>
            About Us
          </Link>
          <Link href="/contact" className={`font-medium ${isActive('/contact') ? 'text-primary' : 'text-neutral-700 hover:text-primary'} transition-colors`}>
            Contact
          </Link>
        </nav>
        
        <div className="flex items-center space-x-4">
          {user ? (
            <div className="hidden md:flex items-center space-x-4">
              <Link href={user.userType === 'customer' ? '/user-dashboard' : '/store-dashboard'} className="font-semibold text-neutral-700 hover:text-primary transition-colors">
                Dashboard
              </Link>
              <Button
                variant="outline"
                className="font-semibold"
                onClick={logout}
              >
                Logout
              </Button>
            </div>
          ) : (
            <div className="hidden md:flex items-center space-x-4">
              <Link href="/login" className="font-semibold text-neutral-700 hover:text-primary transition-colors">
                Login
              </Link>
              <Link href="/signup">
                <Button className="px-4 py-2 bg-primary text-white rounded-full font-semibold hover:bg-primary/90 transition-colors">
                  Sign Up
                </Button>
              </Link>
            </div>
          )}
          
          {/* Mobile Menu Button */}
          <button 
            id="mobile-menu-button" 
            className="md:hidden text-neutral-700 focus:outline-none"
            onClick={toggleMobileMenu}
          >
            <i className="fas fa-bars text-xl"></i>
          </button>
        </div>
      </div>
      
      {/* Mobile Navigation Menu */}
      <div id="mobile-menu" className={`${mobileMenuOpen ? 'block' : 'hidden'} md:hidden bg-white border-t border-neutral-200`}>
        <div className="container mx-auto px-4 py-3 space-y-3">
          <Link href="/" className="block font-medium text-neutral-700 hover:text-primary py-2 transition-colors">
            Home
          </Link>
          <Link href="/stores" className="block font-medium text-neutral-700 hover:text-primary py-2 transition-colors">
            Find Stores
          </Link>
          <Link href="/#how-it-works" className="block font-medium text-neutral-700 hover:text-primary py-2 transition-colors">
            How It Works
          </Link>
          <Link href="/about" className="block font-medium text-neutral-700 hover:text-primary py-2 transition-colors">
            About Us
          </Link>
          <Link href="/contact" className="block font-medium text-neutral-700 hover:text-primary py-2 transition-colors">
            Contact
          </Link>

          {user ? (
            <>
              <Link 
                href={user.userType === 'customer' ? '/user-dashboard' : '/store-dashboard'} 
                className="block font-medium text-neutral-700 hover:text-primary py-2 transition-colors"
              >
                Dashboard
              </Link>
              <button 
                onClick={logout}
                className="block w-full text-left font-medium text-neutral-700 hover:text-primary py-2 transition-colors"
              >
                Logout
              </button>
            </>
          ) : (
            <div className="flex space-x-4 pt-2">
              <Link href="/login" className="w-1/2 px-4 py-2 border border-neutral-300 text-neutral-700 rounded-full font-semibold text-center hover:bg-neutral-100 transition-colors">
                Login
              </Link>
              <Link href="/signup" className="w-1/2 px-4 py-2 bg-primary text-white rounded-full font-semibold text-center hover:bg-primary/90 transition-colors">
                Sign Up
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
