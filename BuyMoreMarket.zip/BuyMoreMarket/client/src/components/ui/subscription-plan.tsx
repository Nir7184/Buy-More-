import { motion } from 'framer-motion';
import { Link } from 'wouter';

interface SubscriptionPlanProps {
  title: string;
  description: string;
  price: number;
  features: string[];
  icon: string;
  colorClass: string;
  link: string;
}

export default function SubscriptionPlan({
  title,
  description,
  price,
  features,
  icon,
  colorClass,
  link
}: SubscriptionPlanProps) {
  return (
    <motion.div 
      className="bg-neutral-50 rounded-2xl p-8 shadow-md hover:shadow-lg transition-shadow border-2 border-transparent hover:border-primary"
      whileHover={{ y: -5 }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="text-2xl font-heading font-bold mb-2">{title}</h3>
          <p className="text-neutral-600">{description}</p>
        </div>
        <div className={`${colorClass} bg-opacity-10 rounded-full p-3`}>
          <i className={`${icon} text-2xl ${colorClass}`}></i>
        </div>
      </div>
      
      <div className="mb-6">
        <div className="text-3xl font-bold text-neutral-900">
          ${price}<span className="text-lg text-neutral-600 font-normal">/month</span>
        </div>
      </div>
      
      <ul className="space-y-4 mb-8">
        {features.map((feature, index) => (
          <li key={index} className="flex items-start">
            <i className={`fas fa-check ${colorClass} mt-1 mr-3`}></i>
            <span>{feature}</span>
          </li>
        ))}
      </ul>
      
      <Link href={link}>
        <a className={`block text-center px-6 py-3 ${colorClass.includes('primary') ? 'bg-primary' : 'bg-[#FF6B35]'} text-white rounded-full font-semibold hover:opacity-90 transition-colors`}>
          Get Started
        </a>
      </Link>
    </motion.div>
  );
}
