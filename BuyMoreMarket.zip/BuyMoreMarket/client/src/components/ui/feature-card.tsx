import { motion } from 'framer-motion';

interface FeatureCardProps {
  icon: string;
  title: string;
  description: string;
  colorClass: string;
}

export default function FeatureCard({ icon, title, description, colorClass }: FeatureCardProps) {
  return (
    <motion.div 
      className="bg-neutral-50 rounded-2xl p-8 shadow-md hover:shadow-lg transition-shadow"
      whileHover={{ y: -5 }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className={`w-16 h-16 ${colorClass} bg-opacity-10 rounded-full flex items-center justify-center mb-6`}>
        <i className={`${icon} text-2xl ${colorClass}`}></i>
      </div>
      <h3 className="text-xl font-heading font-semibold mb-3">{title}</h3>
      <p className="text-neutral-600">{description}</p>
    </motion.div>
  );
}
