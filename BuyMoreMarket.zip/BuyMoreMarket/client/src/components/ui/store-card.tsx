import { Link } from 'wouter';
import { Store } from '@shared/schema';
import { motion } from 'framer-motion';

interface StoreCardProps {
  store: Store;
}

export default function StoreCard({ store }: StoreCardProps) {
  return (
    <motion.div 
      className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all transform"
      whileHover={{ y: -5 }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <img 
        src={store.imageUrl} 
        alt={store.name} 
        className="w-full h-48 object-cover rounded-t-xl" 
      />
      <div className="p-6">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-xl font-heading font-semibold">{store.name}</h3>
          <div className="flex items-center bg-green-100 text-green-800 rounded-full px-2 py-1 text-xs font-medium">
            <i className="fas fa-star text-yellow-400 mr-1"></i> {store.rating.toFixed(1)}
          </div>
        </div>
        <p className="text-neutral-600 text-sm mb-4">{store.description}</p>
        <div className="flex items-center text-sm text-neutral-500 mb-4">
          <i className="fas fa-map-marker-alt mr-2"></i>
          <span>{store.address}</span>
        </div>
        <Link href={`/stores/${store.id}`}>
          <a className="block text-center px-4 py-2 bg-primary text-white rounded-full font-semibold hover:bg-primary/90 transition-colors">
            Shop Now
          </a>
        </Link>
      </div>
    </motion.div>
  );
}
