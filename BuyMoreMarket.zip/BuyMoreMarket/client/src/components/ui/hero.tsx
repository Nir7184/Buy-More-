import { Link } from 'wouter';
import { motion } from 'framer-motion';

export default function Hero() {
  return (
    <section className="relative">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1542838132-92c53300491e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80')",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-primary/90 to-[#2EC4B6]/90"></div>
      </div>
      <div className="container mx-auto px-4 py-24 md:py-32 relative">
        <motion.div
          className="max-w-2xl"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold text-white leading-tight mb-4">
            Skip the Lines, Not the Fresh Groceries
          </h1>
          <p className="text-xl md:text-2xl text-white opacity-90 mb-8">
            Order from your favorite local grocery stores and pick up at your convenience. No delivery fees, just fresh food faster.
          </p>
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
            <Link href="/stores">
              <motion.a
                className="px-8 py-4 bg-white text-primary rounded-full font-semibold text-center text-lg hover:bg-neutral-100 transition-colors inline-block"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Find Stores
              </motion.a>
            </Link>
            <Link href="/#how-it-works">
              <motion.a
                className="px-8 py-4 bg-transparent border-2 border-white text-white rounded-full font-semibold text-center text-lg hover:bg-white hover:text-primary transition-colors inline-block"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                How It Works
              </motion.a>
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
