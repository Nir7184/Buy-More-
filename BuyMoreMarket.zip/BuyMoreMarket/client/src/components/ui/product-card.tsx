import { Product } from '@shared/schema';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/cart-context';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart();

  const handleAddToCart = () => {
    addToCart(product);
  };

  return (
    <motion.div 
      className="flex space-x-4 p-4 border border-neutral-200 rounded-xl hover:border-primary transition-colors"
      whileHover={{ scale: 1.02 }}
    >
      <img 
        src={product.imageUrl} 
        alt={product.name} 
        className="w-24 h-24 rounded-lg object-cover" 
      />
      <div className="flex-1">
        <h4 className="font-medium text-neutral-800">{product.name}</h4>
        <p className="text-sm text-neutral-500 mb-2">{product.unit}</p>
        <div className="flex justify-between items-center">
          <span className="font-semibold text-neutral-900">${product.price.toFixed(2)}</span>
          <Button 
            onClick={handleAddToCart}
            className="px-3 py-1 bg-primary text-white rounded-full text-sm font-medium hover:bg-primary/90 transition-colors"
            disabled={!product.available}
          >
            {product.available ? 'Add to Cart' : 'Out of Stock'}
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
