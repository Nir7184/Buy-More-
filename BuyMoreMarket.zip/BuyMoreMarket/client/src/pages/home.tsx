import { useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { motion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import Hero from '@/components/ui/hero';
import FeatureCard from '@/components/ui/feature-card';
import StoreCard from '@/components/ui/store-card';
import TestimonialCard from '@/components/ui/testimonial-card';
import { Store } from '@shared/schema';

export default function Home() {
  const [location, setLocation] = useLocation();

  // Scroll to section if hash in URL
  useEffect(() => {
    const hash = window.location.hash;
    if (hash) {
      const element = document.querySelector(hash);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, [location]);

  // Fetch featured stores
  const { data: featuredStores = [] } = useQuery<Store[]>({
    queryKey: ['/api/stores/featured'],
  });

  const features = [
    {
      icon: 'fas fa-clock',
      title: 'Schedule Your Pickup',
      description: 'Choose the most convenient time for you to pick up your groceries. No waiting in long checkout lines.',
      colorClass: 'text-primary'
    },
    {
      icon: 'fas fa-store',
      title: 'Support Local Stores',
      description: 'Help your neighborhood grocery stores thrive by ordering directly through our platform.',
      colorClass: 'text-[#FF6B35]'
    },
    {
      icon: 'fas fa-credit-card',
      title: 'Easy Payment Options',
      description: 'Pay online with a small convenience fee or pay in-store during pickup. The choice is yours.',
      colorClass: 'text-[#2EC4B6]'
    }
  ];

  const howItWorks = [
    {
      step: 1,
      title: 'Find a Store',
      description: 'Browse local grocery stores and select one that meets your needs.'
    },
    {
      step: 2,
      title: 'Shop Products',
      description: 'Add items to your cart from the store\'s available inventory.'
    },
    {
      step: 3,
      title: 'Schedule Pickup',
      description: 'Choose your preferred date and time for collecting your groceries.'
    },
    {
      step: 4,
      title: 'Pick Up & Enjoy',
      description: 'Arrive at the store, collect your pre-packed groceries, and you\'re done!'
    }
  ];

  const testimonials = [
    {
      name: 'Sarah Johnson',
      rating: 5,
      text: '"BUY MORE has changed how I shop for groceries. I save so much time by placing my order in advance and picking it up when it\'s convenient for me. No more waiting in long checkout lines!"',
      initial: 'S',
      bgColorClass: 'bg-primary'
    },
    {
      name: 'Michael Thompson',
      rating: 4.5,
      text: '"I love supporting local grocery stores through BUY MORE. The scheduled pickup option fits perfectly with my busy work schedule, and I can pick up my groceries on my way home."',
      initial: 'M',
      bgColorClass: 'bg-[#FF6B35]'
    },
    {
      name: 'Jennifer Williams',
      rating: 5,
      text: '"As a store owner, partnering with BUY MORE has increased our customer base significantly. The platform is easy to use, and it\'s helped us streamline our operations and manage inventory better."',
      initial: 'J',
      bgColorClass: 'bg-[#2EC4B6]'
    }
  ];

  return (
    <>
      {/* Hero Section */}
      <Hero />

      {/* Features Section */}
      <section className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">Why Choose BUY MORE?</h2>
            <p className="text-lg text-neutral-600">Our platform connects you with local grocery stores for a more convenient shopping experience.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <FeatureCard 
                key={index}
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
                colorClass={feature.colorClass}
              />
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-16 md:py-24 bg-neutral-50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">How BUY MORE Works</h2>
            <p className="text-lg text-neutral-600">Shop from local grocery stores and pick up your order when it's convenient for you.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {howItWorks.map((step, index) => (
              <motion.div 
                key={index}
                className="text-center"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <div className="w-20 h-20 bg-primary text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-6">
                  {step.step}
                </div>
                <h3 className="text-xl font-heading font-semibold mb-3">{step.title}</h3>
                <p className="text-neutral-600">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Store Listings Section */}
      <section className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-8">
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">Find Grocery Stores Near You</h2>
            <p className="text-lg text-neutral-600">Browse our partner stores and start shopping for high-quality groceries.</p>
          </div>
          
          {/* Featured Stores */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredStores.map((store) => (
              <StoreCard key={store.id} store={store} />
            ))}
          </div>
          
          <div className="mt-12 text-center">
            <Link href="/stores">
              <motion.a 
                className="inline-block px-8 py-3 border-2 border-primary text-primary rounded-full font-semibold hover:bg-primary hover:text-white transition-colors"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                View All Stores
              </motion.a>
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 md:py-24 bg-neutral-50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">What Our Customers Say</h2>
            <p className="text-lg text-neutral-600">Hear from customers who have simplified their grocery shopping with BUY MORE.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <TestimonialCard 
                key={index}
                name={testimonial.name}
                rating={testimonial.rating}
                text={testimonial.text}
                initial={testimonial.initial}
                bgColorClass={testimonial.bgColorClass}
              />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-primary">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-white mb-6">Ready to Transform Your Grocery Shopping?</h2>
          <p className="text-xl text-white opacity-90 max-w-3xl mx-auto mb-8">Join thousands of satisfied customers who are saving time and supporting local businesses with BUY MORE.</p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Link href="/signup">
              <motion.a 
                className="px-8 py-4 bg-white text-primary rounded-full font-semibold text-center text-lg hover:bg-neutral-100 transition-colors inline-block"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Sign Up Now
              </motion.a>
            </Link>
            <Link href="/stores">
              <motion.a 
                className="px-8 py-4 bg-transparent border-2 border-white text-white rounded-full font-semibold text-center text-lg hover:bg-white hover:text-primary transition-colors inline-block"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Find Stores
              </motion.a>
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
