import { useState } from 'react';
import { useParams } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Store, Product } from '@shared/schema';
import ProductCard from '@/components/ui/product-card';
import { Input } from '@/components/ui/input';
import { useCart } from '@/contexts/cart-context';
import { motion } from 'framer-motion';

export default function StoreDetails() {
  const { id } = useParams<{ id: string }>();
  const [searchTerm, setSearchTerm] = useState('');
  const { storeId } = useCart();

  // Fetch store details
  const { data: store, isLoading: storeLoading } = useQuery<Store>({
    queryKey: [`/api/stores/${id}`],
  });

  // Fetch store products
  const { data: products = [], isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: [`/api/stores/${id}/products`],
  });

  // Filter products based on search term
  const filteredProducts = products.filter(product => 
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  if (storeLoading || productsLoading) {
    return (
      <div className="flex justify-center items-center py-20">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!store) {
    return (
      <div className="container mx-auto px-4 py-12">
        <h1 className="text-2xl font-heading font-bold text-center">Store not found</h1>
      </div>
    );
  }

  return (
    <>
      <section className="bg-primary py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-heading font-bold text-white">{store.name}</h1>
        </div>
      </section>

      <section className="py-8 bg-white">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-2xl shadow-md overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-3">
              {/* Store Info */}
              <div className="p-6 lg:p-8 bg-primary bg-opacity-5 border-b lg:border-b-0 lg:border-r border-neutral-200">
                <div className="flex items-center space-x-4 mb-6">
                  <img 
                    src={store.imageUrl} 
                    alt={store.name} 
                    className="w-16 h-16 rounded-full object-cover" 
                  />
                  <div>
                    <h3 className="text-xl font-heading font-semibold">{store.name}</h3>
                    <div className="flex items-center text-sm">
                      <i className="fas fa-star text-yellow-400 mr-1"></i>
                      <span className="font-medium">{store.rating.toFixed(1)}</span>
                      <span className="text-neutral-500 ml-1">({store.reviewCount} reviews)</span>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4 mb-6">
                  <div className="flex items-start space-x-3">
                    <i className="fas fa-map-marker-alt text-primary mt-1"></i>
                    <div>
                      <p className="font-medium text-neutral-800">{store.address}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <i className="fas fa-clock text-primary mt-1"></i>
                    <div>
                      <p className="font-medium text-neutral-800">Opening Hours</p>
                      <p className="text-sm text-neutral-600">{store.openingHours}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <i className="fas fa-phone-alt text-primary mt-1"></i>
                    <div>
                      <p className="font-medium text-neutral-800">Contact</p>
                      <p className="text-sm text-neutral-600">{store.phone}</p>
                      <p className="text-sm text-neutral-600">{store.email}</p>
                    </div>
                  </div>
                </div>
                
                <div className="text-sm text-neutral-600 mb-4">
                  <p>{store.description}</p>
                </div>
              </div>
              
              {/* Products */}
              <div className="col-span-2 p-6 lg:p-8">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xl font-heading font-semibold">Products</h3>
                  <div className="relative">
                    <Input
                      type="text"
                      placeholder="Search products..."
                      className="pl-10 pr-4 py-2 border border-neutral-300 rounded-full text-sm"
                      value={searchTerm}
                      onChange={handleSearchChange}
                    />
                    <i className="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400"></i>
                  </div>
                </div>
                
                {storeId !== null && storeId !== store.id && (
                  <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg text-sm text-yellow-800">
                    <i className="fas fa-exclamation-triangle mr-2"></i>
                    You already have items in your cart from a different store. Clear your cart to add products from this store.
                  </div>
                )}
                
                {filteredProducts.length > 0 ? (
                  <motion.div 
                    className="grid grid-cols-1 md:grid-cols-2 gap-6"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.3 }}
                  >
                    {filteredProducts.map(product => (
                      <ProductCard key={product.id} product={product} />
                    ))}
                  </motion.div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-neutral-600">No products found matching your search.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
