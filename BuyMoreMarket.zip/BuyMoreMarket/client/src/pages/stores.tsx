import { useState } from 'react';
import { motion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import StoreCard from '@/components/ui/store-card';
import { Store } from '@shared/schema';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';

export default function Stores() {
  const [location, setLocation] = useState('');
  const [storeType, setStoreType] = useState('all');
  const [rating, setRating] = useState('all');

  // Fetch all stores
  const { data: stores = [], isLoading } = useQuery<Store[]>({
    queryKey: ['/api/stores'],
  });

  // Filter stores based on search criteria
  const filteredStores = stores.filter(store => {
    const matchesLocation = !location || 
      store.address.toLowerCase().includes(location.toLowerCase());
    
    const matchesType = !storeType || storeType === 'all' || 
      store.storeSize === storeType;
    
    const matchesRating = !rating || rating === 'all' || 
      (store.rating !== null && store.rating >= parseInt(rating));
    
    return matchesLocation && matchesType && matchesRating;
  });

  return (
    <>
      <section className="bg-primary py-12 md:py-20">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-3xl md:text-4xl font-heading font-bold text-white mb-4">
              Find Grocery Stores Near You
            </h1>
            <p className="text-white text-xl opacity-90">
              Browse our partner stores and start shopping for high-quality groceries.
            </p>
          </div>
        </div>
      </section>

      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          {/* Search & Filter */}
          <motion.div 
            className="max-w-4xl mx-auto mb-12 bg-neutral-50 rounded-xl p-6 shadow-md"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label htmlFor="location" className="block text-neutral-700 text-sm font-medium mb-2">
                  Location
                </label>
                <div className="relative">
                  <Input
                    id="location"
                    placeholder="Enter your address"
                    className="w-full px-4 py-3 border border-neutral-300 rounded-lg pr-10"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                  />
                  <i className="fas fa-map-marker-alt absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400"></i>
                </div>
              </div>
              
              <div>
                <label htmlFor="store-type" className="block text-neutral-700 text-sm font-medium mb-2">
                  Store Type
                </label>
                <Select
                  value={storeType}
                  onValueChange={setStoreType}
                >
                  <SelectTrigger id="store-type" className="w-full px-4 py-3 border border-neutral-300 rounded-lg">
                    <SelectValue placeholder="All Stores" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Stores</SelectItem>
                    <SelectItem value="small">Small Stores</SelectItem>
                    <SelectItem value="medium">Medium Stores</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label htmlFor="rating" className="block text-neutral-700 text-sm font-medium mb-2">
                  Rating
                </label>
                <Select
                  value={rating}
                  onValueChange={setRating}
                >
                  <SelectTrigger id="rating" className="w-full px-4 py-3 border border-neutral-300 rounded-lg">
                    <SelectValue placeholder="All Ratings" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Ratings</SelectItem>
                    <SelectItem value="4">4★ & Above</SelectItem>
                    <SelectItem value="3">3★ & Above</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </motion.div>
          
          {/* Store Listings */}
          {isLoading ? (
            <div className="flex justify-center items-center py-20">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
            </div>
          ) : filteredStores.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredStores.map((store) => (
                <StoreCard key={store.id} store={store} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <h3 className="text-2xl font-heading font-semibold mb-4">No stores found</h3>
              <p className="text-neutral-600 mb-8">
                Try adjusting your search criteria to find more stores.
              </p>
              <Button
                onClick={() => {
                  setLocation('');
                  setStoreType('all');
                  setRating('all');
                }}
                variant="outline"
                className="border-primary text-primary"
              >
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </section>
    </>
  );
}
