import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useAuth } from '@/contexts/auth-context';
import { Store, Product, Order, OrderItem } from '@shared/schema';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';
import { Redirect } from 'wouter';
import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';

interface OrderWithItems extends Order {
  items: Array<OrderItem & { product: Product }>;
  customer: { fullName: string; phone: string; };
}

export default function StoreDashboard() {
  const { user, loading } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('orders');

  // Fetch store data
  const { data: store } = useQuery<Store>({
    queryKey: ['/api/stores/owner'],
    enabled: !!user,
  });

  // Fetch store products
  const { data: products = [] } = useQuery<Product[]>({
    queryKey: ['/api/stores/owner/products'],
    enabled: !!user,
  });

  // Fetch store orders
  const { data: orders = [] } = useQuery<OrderWithItems[]>({
    queryKey: ['/api/stores/owner/orders'],
    enabled: !!user,
  });

  // Update order status mutation
  const updateOrderStatus = useMutation({
    mutationFn: async ({ orderId, status }: { orderId: number; status: string }) => {
      return apiRequest('PATCH', `/api/orders/${orderId}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/stores/owner/orders'] });
      toast({
        title: 'Order Updated',
        description: 'Order status has been successfully updated.',
      });
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to update order status. Please try again.',
        variant: 'destructive',
      });
    },
  });

  // Handle loading state
  if (loading) {
    return (
      <div className="flex justify-center items-center py-20">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Redirect if not logged in
  if (!loading && !user) {
    return <Redirect to="/login" />;
  }

  // Redirect if not a store owner
  if (user && user.userType !== 'store_owner') {
    return <Redirect to="/user-dashboard" />;
  }

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge className="bg-yellow-500">Pending</Badge>;
      case 'ready':
        return <Badge className="bg-green-500">Ready for Pickup</Badge>;
      case 'completed':
        return <Badge className="bg-blue-500">Completed</Badge>;
      case 'cancelled':
        return <Badge className="bg-red-500">Cancelled</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  // Calculate total earnings
  const totalEarnings = orders
    .filter(order => order.status === 'completed')
    .reduce((total, order) => total + order.totalAmount, 0);

  // Get pending orders count
  const pendingOrdersCount = orders.filter(order => order.status === 'pending').length;

  return (
    <div className="bg-neutral-50 min-h-screen py-12">
      <div className="container mx-auto px-4">
        <motion.div 
          className="bg-white rounded-xl shadow-md p-6 mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <h1 className="text-2xl md:text-3xl font-heading font-bold mb-2">
            Store Dashboard
          </h1>
          <p className="text-neutral-600">
            Manage your store, products, and orders here.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <motion.div 
            className="bg-white rounded-xl shadow-md p-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-neutral-600 text-sm">Total Earnings</p>
                <h2 className="text-3xl font-bold text-neutral-900">${totalEarnings.toFixed(2)}</h2>
              </div>
              <div className="w-12 h-12 bg-primary bg-opacity-10 rounded-full flex items-center justify-center">
                <i className="fas fa-dollar-sign text-primary text-xl"></i>
              </div>
            </div>
          </motion.div>

          <motion.div 
            className="bg-white rounded-xl shadow-md p-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.1 }}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-neutral-600 text-sm">Total Products</p>
                <h2 className="text-3xl font-bold text-neutral-900">{products.length}</h2>
              </div>
              <div className="w-12 h-12 bg-[#FF6B35] bg-opacity-10 rounded-full flex items-center justify-center">
                <i className="fas fa-box text-[#FF6B35] text-xl"></i>
              </div>
            </div>
          </motion.div>

          <motion.div 
            className="bg-white rounded-xl shadow-md p-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.2 }}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-neutral-600 text-sm">Pending Orders</p>
                <h2 className="text-3xl font-bold text-neutral-900">{pendingOrdersCount}</h2>
              </div>
              <div className="w-12 h-12 bg-[#2EC4B6] bg-opacity-10 rounded-full flex items-center justify-center">
                <i className="fas fa-clock text-[#2EC4B6] text-xl"></i>
              </div>
            </div>
          </motion.div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid w-full md:w-auto md:inline-grid grid-cols-3 md:grid-cols-4">
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="products">Products</TabsTrigger>
            <TabsTrigger value="store">Store Profile</TabsTrigger>
            <TabsTrigger value="subscription">Subscription</TabsTrigger>
          </TabsList>

          <TabsContent value="orders" className="space-y-4">
            <motion.div 
              className="bg-white rounded-xl shadow-md overflow-hidden"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <div className="p-6 border-b border-neutral-200">
                <h2 className="text-xl font-heading font-semibold">Manage Orders</h2>
                <p className="text-neutral-600 text-sm">View and update customer orders</p>
              </div>

              {orders.length > 0 ? (
                <div className="divide-y divide-neutral-200">
                  {orders.map((order) => (
                    <div key={order.id} className="p-6">
                      <div className="flex flex-col md:flex-row justify-between mb-4">
                        <div>
                          <div className="flex items-center space-x-2 mb-2">
                            <h3 className="font-semibold">Order #{order.id}</h3>
                            {getStatusBadge(order.status)}
                          </div>
                          <p className="text-sm text-neutral-600">
                            Customer: {order.customer.fullName}
                          </p>
                          <p className="text-sm text-neutral-600">
                            Phone: {order.customer.phone || 'N/A'}
                          </p>
                          <p className="text-sm text-neutral-600">
                            Placed: {formatDate(order.createdAt)}
                          </p>
                          <p className="text-sm text-neutral-600">
                            Pickup: {formatDate(order.pickupTime)}
                          </p>
                        </div>
                        <div className="mt-4 md:mt-0">
                          <p className="font-semibold text-right">
                            Total: ${order.totalAmount.toFixed(2)}
                          </p>
                          <p className="text-sm text-neutral-600 text-right">
                            Payment: {order.paymentMethod === 'online' ? 'Paid Online' : 'Pay at Pickup'}
                          </p>
                          {order.paymentMethod === 'online' && (
                            <p className="text-sm text-green-600 text-right">
                              Online Fee: $5.00
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="bg-neutral-50 rounded-lg p-4 mb-4">
                        <h4 className="font-medium mb-2">Items</h4>
                        <div className="space-y-2">
                          {order.items.map((item) => (
                            <div key={item.id} className="flex justify-between">
                              <span>
                                {item.quantity} x {item.product.name}
                              </span>
                              <span className="font-medium">
                                ${(item.price * item.quantity).toFixed(2)}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {order.status !== 'cancelled' && order.status !== 'completed' && (
                        <div className="flex space-x-2 mt-4">
                          {order.status === 'pending' && (
                            <button
                              onClick={() => updateOrderStatus.mutate({ orderId: order.id, status: 'ready' })}
                              className="px-4 py-2 bg-green-500 text-white rounded-lg text-sm hover:bg-green-600 transition-colors"
                            >
                              Mark as Ready
                            </button>
                          )}
                          {order.status === 'ready' && (
                            <button
                              onClick={() => updateOrderStatus.mutate({ orderId: order.id, status: 'completed' })}
                              className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm hover:bg-blue-600 transition-colors"
                            >
                              Mark as Completed
                            </button>
                          )}
                          <button
                            onClick={() => updateOrderStatus.mutate({ orderId: order.id, status: 'cancelled' })}
                            className="px-4 py-2 border border-red-500 text-red-500 rounded-lg text-sm hover:bg-red-50 transition-colors"
                          >
                            Cancel Order
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center">
                  <p className="text-neutral-600">No orders found.</p>
                </div>
              )}
            </motion.div>
          </TabsContent>

          <TabsContent value="products">
            <motion.div 
              className="bg-white rounded-xl shadow-md p-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h2 className="text-xl font-heading font-semibold">Manage Products</h2>
                  <p className="text-neutral-600 text-sm">Add, edit, and remove products from your store</p>
                </div>
                <button className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors">
                  Add New Product
                </button>
              </div>

              {products.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {products.map((product) => (
                    <div 
                      key={product.id} 
                      className="border border-neutral-200 rounded-lg p-4 flex items-center space-x-4"
                    >
                      <img 
                        src={product.imageUrl} 
                        alt={product.name} 
                        className="w-16 h-16 object-cover rounded-md" 
                      />
                      <div className="flex-1">
                        <h3 className="font-medium">{product.name}</h3>
                        <p className="text-sm text-neutral-600 mb-1">{product.unit}</p>
                        <div className="flex justify-between">
                          <span className="font-semibold">${product.price.toFixed(2)}</span>
                          <span className={`text-xs px-2 py-1 rounded-full ${product.available ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                            {product.available ? 'In Stock' : 'Out of Stock'}
                          </span>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <button className="p-2 text-blue-500 hover:bg-blue-50 rounded-full transition-colors">
                          <i className="fas fa-edit"></i>
                        </button>
                        <button className="p-2 text-red-500 hover:bg-red-50 rounded-full transition-colors">
                          <i className="fas fa-trash-alt"></i>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-neutral-600 mb-4">You don't have any products yet.</p>
                  <button className="px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors">
                    Add Your First Product
                  </button>
                </div>
              )}
            </motion.div>
          </TabsContent>

          <TabsContent value="store">
            <motion.div 
              className="bg-white rounded-xl shadow-md p-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <h2 className="text-xl font-heading font-semibold mb-6">Store Profile</h2>
              
              {store ? (
                <div className="space-y-6">
                  <div className="flex flex-col md:flex-row gap-6">
                    <div className="md:w-1/3">
                      <img 
                        src={store.imageUrl} 
                        alt={store.name} 
                        className="w-full h-48 object-cover rounded-lg" 
                      />
                    </div>
                    <div className="md:w-2/3 space-y-4">
                      <div>
                        <h3 className="font-medium text-neutral-800 mb-1">Store Name</h3>
                        <p className="text-neutral-600">{store.name}</p>
                      </div>
                      <div>
                        <h3 className="font-medium text-neutral-800 mb-1">Description</h3>
                        <p className="text-neutral-600">{store.description}</p>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <h3 className="font-medium text-neutral-800 mb-1">Address</h3>
                          <p className="text-neutral-600">{store.address}</p>
                        </div>
                        <div>
                          <h3 className="font-medium text-neutral-800 mb-1">Phone</h3>
                          <p className="text-neutral-600">{store.phone}</p>
                        </div>
                        <div>
                          <h3 className="font-medium text-neutral-800 mb-1">Email</h3>
                          <p className="text-neutral-600">{store.email}</p>
                        </div>
                        <div>
                          <h3 className="font-medium text-neutral-800 mb-1">Opening Hours</h3>
                          <p className="text-neutral-600">{store.openingHours}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="pt-6 border-t border-neutral-200">
                    <button className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors">
                      Edit Store Profile
                    </button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-neutral-600">Store information not available.</p>
                </div>
              )}
            </motion.div>
          </TabsContent>

          <TabsContent value="subscription">
            <motion.div 
              className="bg-white rounded-xl shadow-md p-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <h2 className="text-xl font-heading font-semibold mb-6">Subscription Details</h2>
              
              {store && (
                <div className="space-y-6">
                  <div className="bg-neutral-50 rounded-lg p-6">
                    <div className="flex items-center space-x-4 mb-4">
                      <div className={`w-12 h-12 ${store.storeSize === 'small' ? 'bg-primary' : 'bg-[#FF6B35]'} rounded-full flex items-center justify-center text-white`}>
                        <i className={`fas ${store.storeSize === 'small' ? 'fa-store' : 'fa-store-alt'}`}></i>
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold">
                          {store.storeSize === 'small' ? 'Small Store' : 'Medium Store'} Plan
                        </h3>
                        <p className="text-neutral-600">
                          ${store.subscriptionFee.toFixed(2)}/month
                        </p>
                      </div>
                    </div>
                    
                    <div className="space-y-2 mb-6">
                      <div className="flex justify-between">
                        <span className="text-neutral-600">Billing cycle</span>
                        <span className="font-medium">Monthly</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-600">Next payment</span>
                        <span className="font-medium">July 15, 2023</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-600">Payment method</span>
                        <span className="font-medium">Visa ending in 4242</span>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <button className="w-full px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors">
                        Update Payment Method
                      </button>
                      {store.storeSize === 'small' && (
                        <button className="w-full px-4 py-2 border border-[#FF6B35] text-[#FF6B35] rounded-lg hover:bg-[#FF6B35]/5 transition-colors">
                          Upgrade to Medium Store Plan
                        </button>
                      )}
                      <button className="w-full px-4 py-2 border border-neutral-300 text-neutral-700 rounded-lg hover:bg-neutral-50 transition-colors">
                        View Billing History
                      </button>
                    </div>
                  </div>
                  
                  <div className="rounded-lg border border-neutral-200 p-6">
                    <h3 className="text-lg font-semibold mb-4">Subscription Benefits</h3>
                    <ul className="space-y-3">
                      <li className="flex items-start">
                        <i className="fas fa-check text-primary mt-1 mr-3"></i>
                        <span>Full access to the BUY MORE platform</span>
                      </li>
                      <li className="flex items-start">
                        <i className="fas fa-check text-primary mt-1 mr-3"></i>
                        <span>Order management system</span>
                      </li>
                      <li className="flex items-start">
                        <i className="fas fa-check text-primary mt-1 mr-3"></i>
                        <span>{store.storeSize === 'small' ? 'Basic' : 'Advanced'} inventory management</span>
                      </li>
                      <li className="flex items-start">
                        <i className="fas fa-check text-primary mt-1 mr-3"></i>
                        <span>Customer analytics dashboard</span>
                      </li>
                      {store.storeSize === 'medium' && (
                        <>
                          <li className="flex items-start">
                            <i className="fas fa-check text-primary mt-1 mr-3"></i>
                            <span>Priority listing in search results</span>
                          </li>
                          <li className="flex items-start">
                            <i className="fas fa-check text-primary mt-1 mr-3"></i>
                            <span>Promotional tools and features</span>
                          </li>
                        </>
                      )}
                    </ul>
                  </div>
                </div>
              )}
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
