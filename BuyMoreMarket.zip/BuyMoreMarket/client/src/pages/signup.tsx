import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuth } from '@/contexts/auth-context';
import { useToast } from '@/hooks/use-toast';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { motion } from 'framer-motion';
import { Separator } from '@/components/ui/separator';

// Sign up form schema with validation
const signupFormSchema = z.object({
  username: z.string().min(3, { message: 'Username must be at least 3 characters' }),
  password: z.string().min(6, { message: 'Password must be at least 6 characters' }),
  email: z.string().email({ message: 'Please enter a valid email address' }),
  fullName: z.string().min(2, { message: 'Full name must be at least 2 characters' }),
  phone: z.string().optional(),
  address: z.string().optional(),
  userType: z.enum(['customer', 'store_owner']),
  // Optional store details for store owners
  storeName: z.string().optional(),
  storeDescription: z.string().optional(),
  storeAddress: z.string().optional(),
  storePhone: z.string().optional(),
  storeEmail: z.string().optional(),
  storeOpeningHours: z.string().optional(),
  storeSize: z.enum(['small', 'medium']).optional(),
}).refine((data) => {
  // If user is a store owner, store details are required
  if (data.userType === 'store_owner') {
    return data.storeName && data.storeDescription && data.storeAddress && 
      data.storePhone && data.storeEmail && data.storeOpeningHours && data.storeSize;
  }
  return true;
}, {
  message: "Store details are required for store owners",
  path: ["storeName"],
});

type SignupFormValues = z.infer<typeof signupFormSchema>;

export default function Signup() {
  const [, setLocation] = useLocation();
  const [location] = useLocation();
  const { signup } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  
  // Check if there's a plan specified in the URL
  const searchParams = new URLSearchParams(location.split('?')[1] || '');
  const planFromUrl = searchParams.get('plan');
  
  const [userType, setUserType] = useState<'customer' | 'store_owner'>(
    planFromUrl ? 'store_owner' : 'customer'
  );
  
  const [storeSize, setStoreSize] = useState<'small' | 'medium'>(
    planFromUrl === 'medium' ? 'medium' : 'small'
  );

  // Initialize form with react-hook-form
  const form = useForm<SignupFormValues>({
    resolver: zodResolver(signupFormSchema),
    defaultValues: {
      username: '',
      password: '',
      email: '',
      fullName: '',
      phone: '',
      address: '',
      userType: userType,
      storeName: '',
      storeDescription: '',
      storeAddress: '',
      storePhone: '',
      storeEmail: '',
      storeOpeningHours: '',
      storeSize: storeSize,
    },
  });

  // Update form values when user type changes
  const onUserTypeChange = (value: 'customer' | 'store_owner') => {
    setUserType(value);
    form.setValue('userType', value);
  };

  // Update form values when store size changes
  const onStoreSizeChange = (value: 'small' | 'medium') => {
    setStoreSize(value);
    form.setValue('storeSize', value);
  };

  // Form submission handler
  const onSubmit = async (data: SignupFormValues) => {
    setIsLoading(true);
    try {
      // Prepare data for API call
      const signupData = {
        ...data,
        userType: data.userType,
      };

      // If store owner, add store details
      if (data.userType === 'store_owner') {
        // This is a separate API call in a real implementation
        const storeData = {
          name: data.storeName!,
          description: data.storeDescription!,
          address: data.storeAddress!,
          phone: data.storePhone!,
          email: data.storeEmail!,
          openingHours: data.storeOpeningHours!,
          storeSize: data.storeSize!,
          subscriptionFee: data.storeSize === 'small' ? 180 : 400,
          imageUrl: 'https://images.unsplash.com/photo-1579113800032-c38bd7635818?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
        };
        
        signupData.storeDetails = storeData;
      }

      await signup(signupData);
      toast({
        title: 'Registration Successful',
        description: 'Welcome to BUY MORE!',
      });
      
      // Redirect to dashboard based on user type
      if (data.userType === 'customer') {
        setLocation('/user-dashboard');
      } else {
        setLocation('/store-dashboard');
      }
    } catch (error) {
      let errorMessage = 'Registration failed. Please try again.';
      if (error instanceof Error) {
        errorMessage = error.message;
      }
      toast({
        title: 'Registration Failed',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-neutral-50 py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto">
          <motion.div 
            className="bg-white rounded-xl shadow-md p-8"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="text-center mb-8">
              <h1 className="text-3xl font-heading font-bold text-neutral-900 mb-2">Create an Account</h1>
              <p className="text-neutral-600">Join BUY MORE to shop from local grocery stores or grow your business</p>
            </div>

            <Tabs defaultValue={userType} onValueChange={(value) => onUserTypeChange(value as 'customer' | 'store_owner')}>
              <TabsList className="grid w-full grid-cols-2 mb-8">
                <TabsTrigger value="customer">Customer</TabsTrigger>
                <TabsTrigger value="store_owner">Store Owner</TabsTrigger>
              </TabsList>

              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <TabsContent value="customer">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="fullName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-neutral-700">Full Name</FormLabel>
                            <FormControl>
                              <Input 
                                className="w-full px-4 py-3 border border-neutral-300 rounded-lg" 
                                placeholder="John Doe"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-neutral-700">Email</FormLabel>
                            <FormControl>
                              <Input 
                                type="email"
                                className="w-full px-4 py-3 border border-neutral-300 rounded-lg" 
                                placeholder="john.doe@example.com"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-neutral-700">Phone (Optional)</FormLabel>
                            <FormControl>
                              <Input 
                                className="w-full px-4 py-3 border border-neutral-300 rounded-lg" 
                                placeholder="(123) 456-7890"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="address"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-neutral-700">Address (Optional)</FormLabel>
                            <FormControl>
                              <Input 
                                className="w-full px-4 py-3 border border-neutral-300 rounded-lg" 
                                placeholder="123 Main St, City, State"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="store_owner">
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-lg font-semibold mb-4">Personal Information</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <FormField
                            control={form.control}
                            name="fullName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-neutral-700">Full Name</FormLabel>
                                <FormControl>
                                  <Input 
                                    className="w-full px-4 py-3 border border-neutral-300 rounded-lg" 
                                    placeholder="John Doe"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="email"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-neutral-700">Email</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="email"
                                    className="w-full px-4 py-3 border border-neutral-300 rounded-lg" 
                                    placeholder="john.doe@example.com"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="phone"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-neutral-700">Phone</FormLabel>
                                <FormControl>
                                  <Input 
                                    className="w-full px-4 py-3 border border-neutral-300 rounded-lg" 
                                    placeholder="(123) 456-7890"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="address"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-neutral-700">Address</FormLabel>
                                <FormControl>
                                  <Input 
                                    className="w-full px-4 py-3 border border-neutral-300 rounded-lg" 
                                    placeholder="123 Main St, City, State"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>

                      <Separator />

                      <div>
                        <h3 className="text-lg font-semibold mb-4">Store Information</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <FormField
                            control={form.control}
                            name="storeName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-neutral-700">Store Name</FormLabel>
                                <FormControl>
                                  <Input 
                                    className="w-full px-4 py-3 border border-neutral-300 rounded-lg" 
                                    placeholder="Fresh Market"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="storeEmail"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-neutral-700">Store Email</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="email"
                                    className="w-full px-4 py-3 border border-neutral-300 rounded-lg" 
                                    placeholder="store@example.com"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="storePhone"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-neutral-700">Store Phone</FormLabel>
                                <FormControl>
                                  <Input 
                                    className="w-full px-4 py-3 border border-neutral-300 rounded-lg" 
                                    placeholder="(123) 456-7890"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="storeAddress"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel className="text-neutral-700">Store Address</FormLabel>
                                <FormControl>
                                  <Input 
                                    className="w-full px-4 py-3 border border-neutral-300 rounded-lg" 
                                    placeholder="456 Market St, City, State"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="storeDescription"
                            render={({ field }) => (
                              <FormItem className="col-span-2">
                                <FormLabel className="text-neutral-700">Store Description</FormLabel>
                                <FormControl>
                                  <Input 
                                    className="w-full px-4 py-3 border border-neutral-300 rounded-lg" 
                                    placeholder="A brief description of your store"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="storeOpeningHours"
                            render={({ field }) => (
                              <FormItem className="col-span-2">
                                <FormLabel className="text-neutral-700">Opening Hours</FormLabel>
                                <FormControl>
                                  <Input 
                                    className="w-full px-4 py-3 border border-neutral-300 rounded-lg" 
                                    placeholder="Mon-Sat: 8:00 AM - 9:00 PM, Sun: 9:00 AM - 7:00 PM"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>

                      <Separator />

                      <div>
                        <h3 className="text-lg font-semibold mb-4">Subscription Plan</h3>
                        <FormField
                          control={form.control}
                          name="storeSize"
                          render={({ field }) => (
                            <FormItem className="space-y-3">
                              <FormControl>
                                <RadioGroup
                                  onValueChange={(value) => onStoreSizeChange(value as 'small' | 'medium')}
                                  defaultValue={storeSize}
                                  className="grid grid-cols-2 gap-4"
                                >
                                  <div className={`border rounded-lg p-4 ${storeSize === 'small' ? 'border-primary bg-primary/5' : 'border-neutral-200'}`}>
                                    <RadioGroupItem value="small" id="small" className="sr-only" />
                                    <div className="flex items-center justify-between mb-2">
                                      <label htmlFor="small" className="text-lg font-semibold">Small Store</label>
                                      <div className="w-8 h-8 bg-primary bg-opacity-10 rounded-full flex items-center justify-center">
                                        <i className="fas fa-store text-primary"></i>
                                      </div>
                                    </div>
                                    <p className="text-2xl font-bold mb-1">$180<span className="text-sm font-normal text-neutral-600">/month</span></p>
                                    <p className="text-sm text-neutral-600">Perfect for small local stores</p>
                                  </div>
                                  
                                  <div className={`border rounded-lg p-4 ${storeSize === 'medium' ? 'border-primary bg-primary/5' : 'border-neutral-200'}`}>
                                    <RadioGroupItem value="medium" id="medium" className="sr-only" />
                                    <div className="flex items-center justify-between mb-2">
                                      <label htmlFor="medium" className="text-lg font-semibold">Medium Store</label>
                                      <div className="w-8 h-8 bg-[#FF6B35] bg-opacity-10 rounded-full flex items-center justify-center">
                                        <i className="fas fa-store-alt text-[#FF6B35]"></i>
                                      </div>
                                    </div>
                                    <p className="text-2xl font-bold mb-1">$400<span className="text-sm font-normal text-neutral-600">/month</span></p>
                                    <p className="text-sm text-neutral-600">For established grocery businesses</p>
                                  </div>
                                </RadioGroup>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormDescription className="mt-3 text-sm text-neutral-600">
                          You'll be billed monthly for your subscription. You can change or cancel your plan anytime.
                        </FormDescription>
                      </div>
                    </div>
                  </TabsContent>

                  <Separator />

                  <div className="py-2">
                    <h3 className="text-lg font-semibold mb-4">Account Information</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-neutral-700">Username</FormLabel>
                            <FormControl>
                              <Input 
                                className="w-full px-4 py-3 border border-neutral-300 rounded-lg" 
                                placeholder="Choose a username"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-neutral-700">Password</FormLabel>
                            <FormControl>
                              <Input 
                                type="password"
                                className="w-full px-4 py-3 border border-neutral-300 rounded-lg" 
                                placeholder="Create a secure password"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  <div className="pt-4">
                    <Button 
                      type="submit"
                      className="w-full px-6 py-3 bg-primary text-white rounded-full font-semibold hover:bg-primary/90 transition-colors"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <span className="flex items-center justify-center">
                          <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Creating Account...
                        </span>
                      ) : 'Create Account'}
                    </Button>
                  </div>
                </form>
              </Form>
            </Tabs>

            <div className="mt-8 pt-6 border-t border-neutral-200 text-center">
              <p className="text-neutral-600">
                Already have an account?{' '}
                <Link href="/login">
                  <a className="text-primary font-semibold hover:underline">Sign in</a>
                </Link>
              </p>
            </div>
          </motion.div>

          <div className="mt-8 text-center">
            <Link href="/">
              <a className="text-neutral-600 hover:text-primary inline-flex items-center">
                <i className="fas fa-arrow-left mr-2"></i> Back to Home
              </a>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
