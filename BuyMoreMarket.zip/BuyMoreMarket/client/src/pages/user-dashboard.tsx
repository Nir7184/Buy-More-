import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/contexts/auth-context';
import { Order, OrderItem, Product } from '@shared/schema';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Redirect } from 'wouter';
import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';

interface OrderWithItems extends Order {
  items: Array<OrderItem & { product: Product }>;
}

export default function UserDashboard() {
  const { user, loading } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('orders');

  // Fetch user orders
  const { data: orders = [], isLoading: ordersLoading, refetch: refetchOrders } = useQuery<OrderWithItems[]>({
    queryKey: ['/api/orders/user'],
    enabled: !!user,
  });

  // Handle order cancellation
  const cancelOrder = async (orderId: number) => {
    try {
      await apiRequest('PATCH', `/api/orders/${orderId}/cancel`, {});
      toast({
        title: 'Order Cancelled',
        description: 'Your order has been successfully cancelled.',
      });
      refetchOrders();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to cancel order. Please try again.',
        variant: 'destructive',
      });
    }
  };

  // Handle order pickup time rescheduling
  const rescheduleOrder = async (orderId: number, newTime: string) => {
    try {
      await apiRequest('PATCH', `/api/orders/${orderId}/reschedule`, { pickupTime: newTime });
      toast({
        title: 'Pickup Time Updated',
        description: 'Your pickup time has been successfully rescheduled.',
      });
      refetchOrders();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to reschedule pickup. Please try again.',
        variant: 'destructive',
      });
    }
  };

  // Handle loading state
  if (loading) {
    return (
      <div className="flex justify-center items-center py-20">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Redirect if not logged in
  if (!loading && !user) {
    return <Redirect to="/login" />;
  }

  // Redirect if not a customer
  if (user && user.userType !== 'customer') {
    return <Redirect to="/store-dashboard" />;
  }

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge className="bg-yellow-500">Pending</Badge>;
      case 'ready':
        return <Badge className="bg-green-500">Ready for Pickup</Badge>;
      case 'completed':
        return <Badge className="bg-blue-500">Completed</Badge>;
      case 'cancelled':
        return <Badge className="bg-red-500">Cancelled</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="bg-neutral-50 min-h-screen py-12">
      <div className="container mx-auto px-4">
        <motion.div 
          className="bg-white rounded-xl shadow-md p-6 mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <h1 className="text-2xl md:text-3xl font-heading font-bold mb-2">
            Welcome, {user?.fullName}!
          </h1>
          <p className="text-neutral-600">
            Manage your orders and account settings here.
          </p>
        </motion.div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid w-full md:w-auto md:inline-grid grid-cols-2 md:grid-cols-3">
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="settings">Account Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="orders" className="space-y-4">
            <motion.div 
              className="bg-white rounded-xl shadow-md overflow-hidden"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <div className="p-6 border-b border-neutral-200">
                <h2 className="text-xl font-heading font-semibold">Your Orders</h2>
                <p className="text-neutral-600 text-sm">View and manage your pickup orders</p>
              </div>

              {ordersLoading ? (
                <div className="p-6 text-center">
                  <div className="animate-spin mx-auto rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                </div>
              ) : orders.length > 0 ? (
                <div className="divide-y divide-neutral-200">
                  {orders.map((order) => (
                    <div key={order.id} className="p-6">
                      <div className="flex flex-col md:flex-row justify-between mb-4">
                        <div>
                          <div className="flex items-center space-x-2 mb-2">
                            <h3 className="font-semibold">Order #{order.id}</h3>
                            {getStatusBadge(order.status)}
                          </div>
                          <p className="text-sm text-neutral-600">
                            Placed: {formatDate(order.createdAt)}
                          </p>
                          <p className="text-sm text-neutral-600">
                            Pickup: {formatDate(order.pickupTime)}
                          </p>
                        </div>
                        <div className="mt-4 md:mt-0">
                          <p className="font-semibold text-right">
                            Total: ${order.totalAmount.toFixed(2)}
                          </p>
                          <p className="text-sm text-neutral-600 text-right">
                            Payment: {order.paymentMethod === 'online' ? 'Paid Online' : 'Pay at Pickup'}
                          </p>
                          {order.lateFee > 0 && (
                            <p className="text-sm text-red-600 text-right">
                              Late Fee: ${order.lateFee.toFixed(2)}
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="bg-neutral-50 rounded-lg p-4 mb-4">
                        <h4 className="font-medium mb-2">Items</h4>
                        <div className="space-y-2">
                          {order.items.map((item) => (
                            <div key={item.id} className="flex justify-between">
                              <span>
                                {item.quantity} x {item.product.name}
                              </span>
                              <span className="font-medium">
                                ${(item.price * item.quantity).toFixed(2)}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {order.status === 'pending' && (
                        <div className="flex space-x-2 mt-4">
                          <button
                            onClick={() => cancelOrder(order.id)}
                            className="px-4 py-2 border border-red-500 text-red-500 rounded-lg text-sm hover:bg-red-50 transition-colors"
                          >
                            Cancel Order
                          </button>
                          <button
                            className="px-4 py-2 border border-primary text-primary rounded-lg text-sm hover:bg-primary/5 transition-colors"
                            onClick={() => {
                              const newTime = prompt(
                                'Enter new pickup time (YYYY-MM-DD HH:MM)',
                                new Date(order.pickupTime).toISOString().slice(0, 16).replace('T', ' ')
                              );
                              if (newTime) rescheduleOrder(order.id, newTime);
                            }}
                          >
                            Reschedule Pickup
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center">
                  <p className="text-neutral-600">You don't have any orders yet.</p>
                </div>
              )}
            </motion.div>
          </TabsContent>

          <TabsContent value="settings">
            <motion.div 
              className="bg-white rounded-xl shadow-md p-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <h2 className="text-xl font-heading font-semibold mb-4">Account Settings</h2>
              
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium text-neutral-800 mb-1">Username</h3>
                  <p className="text-neutral-600">{user?.username}</p>
                </div>
                <div>
                  <h3 className="font-medium text-neutral-800 mb-1">Email</h3>
                  <p className="text-neutral-600">{user?.email}</p>
                </div>
                <div>
                  <h3 className="font-medium text-neutral-800 mb-1">Full Name</h3>
                  <p className="text-neutral-600">{user?.fullName}</p>
                </div>
                {user?.phone && (
                  <div>
                    <h3 className="font-medium text-neutral-800 mb-1">Phone</h3>
                    <p className="text-neutral-600">{user.phone}</p>
                  </div>
                )}
                {user?.address && (
                  <div>
                    <h3 className="font-medium text-neutral-800 mb-1">Address</h3>
                    <p className="text-neutral-600">{user.address}</p>
                  </div>
                )}
              </div>
              
              <div className="mt-6 pt-6 border-t border-neutral-200">
                <button className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors">
                  Edit Profile
                </button>
              </div>
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
