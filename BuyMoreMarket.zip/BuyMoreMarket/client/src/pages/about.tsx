import { Link } from 'wouter';
import { motion } from 'framer-motion';
import SubscriptionPlan from '@/components/ui/subscription-plan';

export default function About() {
  return (
    <>
      <section className="bg-primary py-12 md:py-20">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-3xl md:text-4xl font-heading font-bold text-white mb-4">
              About BUY MORE
            </h1>
            <p className="text-white text-xl opacity-90">
              Connecting customers with local grocery stores for a better shopping experience.
            </p>
          </div>
        </div>
      </section>

      <section id="about" className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-3xl md:text-4xl font-heading font-bold mb-6">About BUY MORE</h2>
              <p className="text-lg text-neutral-600 mb-6">
                BUY MORE is a revolutionary platform connecting consumers with local grocery stores. We believe in making grocery shopping more convenient while supporting local businesses.
              </p>
              <p className="text-lg text-neutral-600 mb-6">
                Our unique model focuses on scheduled pickups rather than deliveries, eliminating delivery fees and giving you more control over when you receive your groceries.
              </p>
              
              <h3 className="text-xl font-heading font-semibold mt-8 mb-4">For Customers</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-primary mt-1 mr-3"></i>
                  <span>Shop from multiple local stores in one place</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-primary mt-1 mr-3"></i>
                  <span>Schedule convenient pickup times that fit your schedule</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-primary mt-1 mr-3"></i>
                  <span>Avoid delivery fees while still saving time</span>
                </li>
              </ul>
              
              <h3 className="text-xl font-heading font-semibold mt-8 mb-4">For Store Owners</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#FF6B35] mt-1 mr-3"></i>
                  <span>Increase your customer base and revenue</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#FF6B35] mt-1 mr-3"></i>
                  <span>Streamline order management and inventory</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#FF6B35] mt-1 mr-3"></i>
                  <span>Affordable subscription plans for businesses of all sizes</span>
                </li>
              </ul>
            </motion.div>
            
            <motion.div 
              className="grid grid-cols-2 gap-4"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <img 
                src="https://images.unsplash.com/photo-1542838132-92c53300491e?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                alt="Grocery Store Interior" 
                className="rounded-xl shadow-md object-cover h-64" 
              />
              <img 
                src="https://images.unsplash.com/photo-1608686207856-001b95cf60ca?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                alt="Fresh Produce" 
                className="rounded-xl shadow-md object-cover h-64 mt-8" 
              />
              <img 
                src="https://images.unsplash.com/photo-1534723452862-4c874018d66d?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                alt="Store Owner" 
                className="rounded-xl shadow-md object-cover h-64 mt-8" 
              />
              <img 
                src="https://images.unsplash.com/photo-1579113800032-c38bd7635818?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                alt="Customer Shopping" 
                className="rounded-xl shadow-md object-cover h-64" 
              />
            </motion.div>
          </div>
        </div>
      </section>

      <section id="subscription-plans" className="py-16 md:py-24 bg-neutral-50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">Partner With Us</h2>
            <p className="text-lg text-neutral-600">Join BUY MORE as a store owner and grow your business with our platform.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <SubscriptionPlan
              title="Small Store"
              description="Perfect for small local grocery stores"
              price={180}
              features={[
                "Full access to the BUY MORE platform",
                "Order management system",
                "Basic inventory management",
                "Customer analytics dashboard",
                "Email support"
              ]}
              icon="fas fa-store"
              colorClass="text-primary"
              link="/signup?plan=small"
            />
            
            <SubscriptionPlan
              title="Medium Store"
              description="Ideal for established grocery businesses"
              price={400}
              features={[
                "Everything in Small Store plan",
                "Advanced inventory management",
                "Priority listing in search results",
                "Promotional tools and features",
                "Priority phone & email support"
              ]}
              icon="fas fa-store-alt"
              colorClass="text-[#FF6B35]"
              link="/signup?plan=medium"
            />
          </div>
        </div>
      </section>

      <section id="success-stories" className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">Success Stories</h2>
            <p className="text-lg text-neutral-600">Hear from store owners who have grown their business with BUY MORE.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <motion.div 
              className="bg-neutral-50 rounded-xl p-8 shadow-md"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <div className="flex items-center space-x-4 mb-6">
                <img 
                  src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80" 
                  alt="David Thompson" 
                  className="w-16 h-16 rounded-full object-cover" 
                />
                <div>
                  <h3 className="font-semibold text-lg">David Thompson</h3>
                  <p className="text-neutral-600">Owner, Fresh Market Grocery</p>
                </div>
              </div>
              <p className="text-neutral-700 mb-4">
                "Since joining BUY MORE, our small grocery store has seen a 40% increase in sales. The platform's easy-to-use interface and efficient order management system have transformed how we do business."
              </p>
              <p className="text-neutral-700">
                "What I love most is that we can focus on what we do best—providing quality products—while BUY MORE handles the digital side of things."
              </p>
            </motion.div>
            
            <motion.div 
              className="bg-neutral-50 rounded-xl p-8 shadow-md"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <div className="flex items-center space-x-4 mb-6">
                <img 
                  src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80" 
                  alt="Sarah Miller" 
                  className="w-16 h-16 rounded-full object-cover" 
                />
                <div>
                  <h3 className="font-semibold text-lg">Sarah Miller</h3>
                  <p className="text-neutral-600">Manager, Urban Grocers</p>
                </div>
              </div>
              <p className="text-neutral-700 mb-4">
                "BUY MORE has helped us reach customers we never would have connected with otherwise. The scheduled pickup system has reduced congestion in our store and allowed us to serve more customers efficiently."
              </p>
              <p className="text-neutral-700">
                "The analytics tools have given us valuable insights into our most popular products, helping us optimize our inventory and reduce waste."
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      <section id="resources" className="py-16 md:py-24 bg-neutral-50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">Resources</h2>
            <p className="text-lg text-neutral-600">Helpful guides and tools for store owners and customers.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <motion.div 
              className="bg-white rounded-xl p-6 shadow-md"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <div className="w-12 h-12 bg-primary bg-opacity-10 rounded-full flex items-center justify-center mb-4">
                <i className="fas fa-book text-primary"></i>
              </div>
              <h3 className="text-xl font-heading font-semibold mb-3">Store Owner Guide</h3>
              <p className="text-neutral-600 mb-4">
                Everything you need to know to set up and manage your store on BUY MORE.
              </p>
              <a href="#" className="text-primary font-medium hover:underline">Download Guide →</a>
            </motion.div>
            
            <motion.div 
              className="bg-white rounded-xl p-6 shadow-md"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <div className="w-12 h-12 bg-[#FF6B35] bg-opacity-10 rounded-full flex items-center justify-center mb-4">
                <i className="fas fa-video text-[#FF6B35]"></i>
              </div>
              <h3 className="text-xl font-heading font-semibold mb-3">Video Tutorials</h3>
              <p className="text-neutral-600 mb-4">
                Step-by-step video guides on using all the features of the BUY MORE platform.
              </p>
              <a href="#" className="text-[#FF6B35] font-medium hover:underline">Watch Videos →</a>
            </motion.div>
            
            <motion.div 
              className="bg-white rounded-xl p-6 shadow-md"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.2 }}
            >
              <div className="w-12 h-12 bg-[#2EC4B6] bg-opacity-10 rounded-full flex items-center justify-center mb-4">
                <i className="fas fa-question-circle text-[#2EC4B6]"></i>
              </div>
              <h3 className="text-xl font-heading font-semibold mb-3">FAQs</h3>
              <p className="text-neutral-600 mb-4">
                Answers to common questions about shopping and selling on BUY MORE.
              </p>
              <a href="#" className="text-[#2EC4B6] font-medium hover:underline">View FAQs →</a>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-24 bg-primary">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-white mb-6">Ready to Join BUY MORE?</h2>
          <p className="text-xl text-white opacity-90 max-w-3xl mx-auto mb-8">Whether you're a customer looking to save time or a store owner wanting to grow your business, BUY MORE has a solution for you.</p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Link href="/signup">
              <motion.a 
                className="px-8 py-4 bg-white text-primary rounded-full font-semibold text-center text-lg hover:bg-neutral-100 transition-colors inline-block"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Sign Up Now
              </motion.a>
            </Link>
            <Link href="/contact">
              <motion.a 
                className="px-8 py-4 bg-transparent border-2 border-white text-white rounded-full font-semibold text-center text-lg hover:bg-white hover:text-primary transition-colors inline-block"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Contact Us
              </motion.a>
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
