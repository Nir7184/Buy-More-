import { 
  users, type User, type InsertUser,
  stores, type Store, type InsertStore,
  products, type Product, type InsertProduct,
  orders, type Order, type InsertOrder,
  orderItems, type OrderItem, type InsertOrderItem,
  reviews, type Review, type InsertReview,
  contactMessages, type ContactMessage, type InsertContactMessage,
  cartSessions, type CartSession, type InsertCartSession,
  cartItems, type CartItem, type InsertCartItem
} from "@shared/schema";

// Memory storage interface for all entity types
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User>;
  
  // Store methods
  getStore(id: number): Promise<Store | undefined>;
  getAllStores(): Promise<Store[]>;
  getFeaturedStores(limit?: number): Promise<Store[]>;
  getStoreByOwner(ownerId: number): Promise<Store | undefined>;
  createStore(store: InsertStore): Promise<Store>;
  updateStore(id: number, data: Partial<Store>): Promise<Store>;
  
  // Product methods
  getProduct(id: number): Promise<Product | undefined>;
  getProductsByStore(storeId: number): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, data: Partial<Product>): Promise<Product>;
  deleteProduct(id: number): Promise<void>;
  
  // Order methods
  getOrder(id: number): Promise<Order | undefined>;
  getOrdersByUser(userId: number): Promise<Order[]>;
  getOrdersByStore(storeId: number): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: number, data: Partial<Order>): Promise<Order>;
  
  // Order Item methods
  getOrderItem(id: number): Promise<OrderItem | undefined>;
  getOrderItemsByOrder(orderId: number): Promise<OrderItem[]>;
  createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem>;
  
  // Review methods
  getReview(id: number): Promise<Review | undefined>;
  getReviewsByStore(storeId: number): Promise<Review[]>;
  getReviewByUserAndStore(userId: number, storeId: number): Promise<Review | undefined>;
  createReview(review: InsertReview): Promise<Review>;
  
  // Contact message methods
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
  
  // Cart session methods
  getCartSession(id: number): Promise<CartSession | undefined>;
  getCartSessionBySessionId(sessionId: string): Promise<CartSession | undefined>;
  createCartSession(session: InsertCartSession): Promise<CartSession>;
  updateCartSession(id: number, data: Partial<CartSession>): Promise<CartSession>;
  deleteCartSession(id: number): Promise<void>;
  
  // Cart item methods
  getCartItem(id: number): Promise<CartItem | undefined>;
  getCartItemsBySession(sessionId: number): Promise<CartItem[]>;
  getCartItemByProductAndSession(productId: number, sessionId: number): Promise<CartItem | undefined>;
  createCartItem(item: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: number, data: Partial<CartItem>): Promise<CartItem>;
  deleteCartItem(id: number): Promise<void>;
  deleteCartItemsBySession(sessionId: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private stores: Map<number, Store>;
  private products: Map<number, Product>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem>;
  private reviews: Map<number, Review>;
  private contactMessages: Map<number, ContactMessage>;
  private cartSessions: Map<number, CartSession>;
  private cartItems: Map<number, CartItem>;

  // ID counters for each entity
  private userIdCounter: number;
  private storeIdCounter: number;
  private productIdCounter: number;
  private orderIdCounter: number;
  private orderItemIdCounter: number;
  private reviewIdCounter: number;
  private contactMessageIdCounter: number;
  private cartSessionIdCounter: number;
  private cartItemIdCounter: number;

  constructor() {
    // Initialize Maps for storing entities
    this.users = new Map();
    this.stores = new Map();
    this.products = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    this.reviews = new Map();
    this.contactMessages = new Map();
    this.cartSessions = new Map();
    this.cartItems = new Map();

    // Initialize ID counters
    this.userIdCounter = 1;
    this.storeIdCounter = 1;
    this.productIdCounter = 1;
    this.orderIdCounter = 1;
    this.orderItemIdCounter = 1;
    this.reviewIdCounter = 1;
    this.contactMessageIdCounter = 1;
    this.cartSessionIdCounter = 1;
    this.cartItemIdCounter = 1;

    // Add some sample data for development
    this.initSampleData();
  }

  private initSampleData(): void {
    // Sample users
    const user1 = this.createUser({
      username: "customer1",
      password: "password123",
      email: "customer1@example.com",
      fullName: "John Customer",
      phone: "(123) 456-7890",
      address: "123 Main St, Anytown, USA",
      userType: "customer"
    });

    const user2 = this.createUser({
      username: "storeowner1",
      password: "password123",
      email: "store1@example.com",
      fullName: "Jane StoreOwner",
      phone: "(123) 456-7891",
      address: "456 Market St, Anytown, USA",
      userType: "store_owner"
    });

    const user3 = this.createUser({
      username: "storeowner2",
      password: "password123",
      email: "store2@example.com",
      fullName: "Bob Merchant",
      phone: "(123) 456-7892",
      address: "789 Grove St, Anytown, USA",
      userType: "store_owner"
    });

    // Sample stores
    const store1 = this.createStore({
      name: "Fresh Market",
      description: "Small local grocery store with focus on organic produce and specialty items",
      address: "456 Market St, Anytown, USA",
      phone: "(123) 456-7891",
      email: "fresh@example.com",
      openingHours: "Mon-Sat: 8:00 AM - 9:00 PM, Sun: 9:00 AM - 7:00 PM",
      imageUrl: "https://images.unsplash.com/photo-1534723452862-4c874018d66d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      rating: 4.8,
      reviewCount: 120,
      storeSize: "small",
      subscriptionFee: 180,
      ownerId: user2.id,
      latitude: 40.7128,
      longitude: -74.0060
    });

    const store2 = this.createStore({
      name: "Urban Grocers",
      description: "Medium-sized store with extensive selection and competitive prices",
      address: "789 Grove St, Anytown, USA",
      phone: "(123) 456-7892",
      email: "urban@example.com",
      openingHours: "Mon-Sun: 7:00 AM - 10:00 PM",
      imageUrl: "https://images.unsplash.com/photo-1579113800032-c38bd7635818?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      rating: 4.5,
      reviewCount: 95,
      storeSize: "medium",
      subscriptionFee: 400,
      ownerId: user3.id,
      latitude: 40.7138,
      longitude: -74.0070
    });
    
    const store3 = this.createStore({
      name: "The Fresh Market",
      description: "Premium supermarket specializing in gourmet and organic products with a wide selection of fresh produce",
      address: "123 Gourmet Blvd, Anytown, USA",
      phone: "(123) 456-7893",
      email: "thefreshmarket@example.com",
      openingHours: "Mon-Sat: 8:00 AM - 10:00 PM, Sun: 9:00 AM - 8:00 PM",
      imageUrl: "https://images.unsplash.com/photo-1543083477-4f785aeafaa9?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      rating: 4.9,
      reviewCount: 210,
      storeSize: "medium",
      subscriptionFee: 450,
      ownerId: user2.id,
      latitude: 40.7150,
      longitude: -74.0055
    });

    // Sample products for store 1
    this.createProduct({
      name: "Organic Apples",
      description: "Fresh local organic apples",
      price: 3.99,
      imageUrl: "https://images.unsplash.com/photo-1610832958506-aa56368176cf?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80",
      category: "Fruits",
      unit: "1lb package",
      available: true,
      storeId: store1.id
    });

    this.createProduct({
      name: "Artisan Bread",
      description: "Freshly baked artisan bread",
      price: 4.50,
      imageUrl: "https://images.unsplash.com/photo-1594489573458-2456f5c64f40?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80",
      category: "Bakery",
      unit: "Loaf",
      available: true,
      storeId: store1.id
    });

    this.createProduct({
      name: "Organic Milk",
      description: "Local organic whole milk",
      price: 3.75,
      imageUrl: "https://images.unsplash.com/photo-1628088062854-d1870b4553da?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80",
      category: "Dairy",
      unit: "Half Gallon",
      available: true,
      storeId: store1.id
    });

    // Sample products for store 2
    this.createProduct({
      name: "Ripe Avocados",
      description: "Premium ripe avocados",
      price: 5.99,
      imageUrl: "https://images.unsplash.com/photo-1604652716188-a5c64c8c3f33?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80",
      category: "Fruits",
      unit: "Pack of 4",
      available: true,
      storeId: store2.id
    });

    this.createProduct({
      name: "Grass-fed Ground Beef",
      description: "Local grass-fed ground beef",
      price: 7.50,
      imageUrl: "https://images.unsplash.com/photo-1551135020-39e4ca508d9b?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80",
      category: "Meat",
      unit: "1lb package",
      available: true,
      storeId: store2.id
    });

    this.createProduct({
      name: "Cage-free Eggs",
      description: "Local cage-free eggs",
      price: 4.25,
      imageUrl: "https://images.unsplash.com/photo-1565279427445-10c13a37d2be?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80",
      category: "Dairy",
      unit: "Dozen",
      available: true,
      storeId: store2.id
    });
    
    // Sample products for The Fresh Market (store3)
    this.createProduct({
      name: "Premium Salmon Fillets",
      description: "Fresh Atlantic salmon, sustainably sourced",
      price: 12.99,
      imageUrl: "https://images.unsplash.com/photo-1599084993091-1cb5c0721cc6?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80",
      category: "Seafood",
      unit: "1lb package",
      available: true,
      storeId: store3.id
    });
    
    this.createProduct({
      name: "Organic Acai Bowl Mix",
      description: "Ready-to-blend premium organic acai with granola topping",
      price: 8.49,
      imageUrl: "https://images.unsplash.com/photo-1590301157890-4810ed352733?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80",
      category: "Frozen",
      unit: "16oz container",
      available: true,
      storeId: store3.id
    });
    
    this.createProduct({
      name: "Imported Parmesan Reggiano",
      description: "Authentic 24-month aged Italian Parmesan",
      price: 15.99,
      imageUrl: "https://images.unsplash.com/photo-1552767059-ce182eda88cc?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80",
      category: "Cheese",
      unit: "8oz wedge",
      available: true,
      storeId: store3.id
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    for (const user of this.users.values()) {
      if (user.username.toLowerCase() === username.toLowerCase()) {
        return user;
      }
    }
    return undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    for (const user of this.users.values()) {
      if (user.email.toLowerCase() === email.toLowerCase()) {
        return user;
      }
    }
    return undefined;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = {
      id,
      ...userData
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, data: Partial<User>): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with ID ${id} not found`);
    }

    const updatedUser = { ...user, ...data };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Store methods
  async getStore(id: number): Promise<Store | undefined> {
    return this.stores.get(id);
  }

  async getAllStores(): Promise<Store[]> {
    return Array.from(this.stores.values());
  }

  async getFeaturedStores(limit: number = 3): Promise<Store[]> {
    // In a real app, you might have a featured field or sort by rating
    return Array.from(this.stores.values())
      .sort((a, b) => b.rating - a.rating)
      .slice(0, limit);
  }

  async getStoreByOwner(ownerId: number): Promise<Store | undefined> {
    for (const store of this.stores.values()) {
      if (store.ownerId === ownerId) {
        return store;
      }
    }
    return undefined;
  }

  async createStore(storeData: InsertStore): Promise<Store> {
    const id = this.storeIdCounter++;
    const store: Store = {
      id,
      ...storeData,
      rating: storeData.rating || 0,
      reviewCount: storeData.reviewCount || 0
    };
    this.stores.set(id, store);
    return store;
  }

  async updateStore(id: number, data: Partial<Store>): Promise<Store> {
    const store = await this.getStore(id);
    if (!store) {
      throw new Error(`Store with ID ${id} not found`);
    }

    const updatedStore = { ...store, ...data };
    this.stores.set(id, updatedStore);
    return updatedStore;
  }

  // Product methods
  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductsByStore(storeId: number): Promise<Product[]> {
    const storeProducts: Product[] = [];
    for (const product of this.products.values()) {
      if (product.storeId === storeId) {
        storeProducts.push(product);
      }
    }
    return storeProducts;
  }

  async createProduct(productData: InsertProduct): Promise<Product> {
    const id = this.productIdCounter++;
    const product: Product = {
      id,
      ...productData
    };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: number, data: Partial<Product>): Promise<Product> {
    const product = await this.getProduct(id);
    if (!product) {
      throw new Error(`Product with ID ${id} not found`);
    }

    const updatedProduct = { ...product, ...data };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }

  async deleteProduct(id: number): Promise<void> {
    if (!this.products.has(id)) {
      throw new Error(`Product with ID ${id} not found`);
    }
    this.products.delete(id);
  }

  // Order methods
  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async getOrdersByUser(userId: number): Promise<Order[]> {
    const userOrders: Order[] = [];
    for (const order of this.orders.values()) {
      if (order.userId === userId) {
        userOrders.push(order);
      }
    }
    return userOrders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getOrdersByStore(storeId: number): Promise<Order[]> {
    const storeOrders: Order[] = [];
    for (const order of this.orders.values()) {
      if (order.storeId === storeId) {
        storeOrders.push(order);
      }
    }
    return storeOrders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createOrder(orderData: InsertOrder): Promise<Order> {
    const id = this.orderIdCounter++;
    const order: Order = {
      id,
      ...orderData,
      createdAt: new Date(),
      lateFee: orderData.lateFee || 0,
      paymentFee: orderData.paymentMethod === 'online' ? 5 : 0
    };
    this.orders.set(id, order);
    return order;
  }

  async updateOrder(id: number, data: Partial<Order>): Promise<Order> {
    const order = await this.getOrder(id);
    if (!order) {
      throw new Error(`Order with ID ${id} not found`);
    }

    const updatedOrder = { ...order, ...data };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  // Order Item methods
  async getOrderItem(id: number): Promise<OrderItem | undefined> {
    return this.orderItems.get(id);
  }

  async getOrderItemsByOrder(orderId: number): Promise<OrderItem[]> {
    const items: OrderItem[] = [];
    for (const item of this.orderItems.values()) {
      if (item.orderId === orderId) {
        items.push(item);
      }
    }
    return items;
  }

  async createOrderItem(itemData: InsertOrderItem): Promise<OrderItem> {
    const id = this.orderItemIdCounter++;
    const orderItem: OrderItem = {
      id,
      ...itemData
    };
    this.orderItems.set(id, orderItem);
    return orderItem;
  }

  // Review methods
  async getReview(id: number): Promise<Review | undefined> {
    return this.reviews.get(id);
  }

  async getReviewsByStore(storeId: number): Promise<Review[]> {
    const storeReviews: Review[] = [];
    for (const review of this.reviews.values()) {
      if (review.storeId === storeId) {
        storeReviews.push(review);
      }
    }
    return storeReviews.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getReviewByUserAndStore(userId: number, storeId: number): Promise<Review | undefined> {
    for (const review of this.reviews.values()) {
      if (review.userId === userId && review.storeId === storeId) {
        return review;
      }
    }
    return undefined;
  }

  async createReview(reviewData: InsertReview): Promise<Review> {
    const id = this.reviewIdCounter++;
    const review: Review = {
      id,
      ...reviewData,
      createdAt: new Date()
    };
    this.reviews.set(id, review);
    return review;
  }

  // Contact message methods
  async createContactMessage(messageData: InsertContactMessage): Promise<ContactMessage> {
    const id = this.contactMessageIdCounter++;
    const message: ContactMessage = {
      id,
      ...messageData,
      createdAt: new Date()
    };
    this.contactMessages.set(id, message);
    return message;
  }

  // Cart session methods
  async getCartSession(id: number): Promise<CartSession | undefined> {
    return this.cartSessions.get(id);
  }

  async getCartSessionBySessionId(sessionId: string): Promise<CartSession | undefined> {
    for (const session of this.cartSessions.values()) {
      if (session.sessionId === sessionId) {
        return session;
      }
    }
    return undefined;
  }

  async createCartSession(sessionData: InsertCartSession): Promise<CartSession> {
    const id = this.cartSessionIdCounter++;
    const session: CartSession = {
      id,
      ...sessionData,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.cartSessions.set(id, session);
    return session;
  }

  async updateCartSession(id: number, data: Partial<CartSession>): Promise<CartSession> {
    const session = await this.getCartSession(id);
    if (!session) {
      throw new Error(`Cart session with ID ${id} not found`);
    }

    const updatedSession = { ...session, ...data };
    this.cartSessions.set(id, updatedSession);
    return updatedSession;
  }

  async deleteCartSession(id: number): Promise<void> {
    if (!this.cartSessions.has(id)) {
      throw new Error(`Cart session with ID ${id} not found`);
    }
    this.cartSessions.delete(id);
  }

  // Cart item methods
  async getCartItem(id: number): Promise<CartItem | undefined> {
    return this.cartItems.get(id);
  }

  async getCartItemsBySession(sessionId: number): Promise<CartItem[]> {
    const items: CartItem[] = [];
    for (const item of this.cartItems.values()) {
      if (item.cartSessionId === sessionId) {
        items.push(item);
      }
    }
    return items;
  }

  async getCartItemByProductAndSession(productId: number, sessionId: number): Promise<CartItem | undefined> {
    for (const item of this.cartItems.values()) {
      if (item.productId === productId && item.cartSessionId === sessionId) {
        return item;
      }
    }
    return undefined;
  }

  async createCartItem(itemData: InsertCartItem): Promise<CartItem> {
    const id = this.cartItemIdCounter++;
    const cartItem: CartItem = {
      id,
      ...itemData
    };
    this.cartItems.set(id, cartItem);
    return cartItem;
  }

  async updateCartItem(id: number, data: Partial<CartItem>): Promise<CartItem> {
    const item = await this.getCartItem(id);
    if (!item) {
      throw new Error(`Cart item with ID ${id} not found`);
    }

    const updatedItem = { ...item, ...data };
    this.cartItems.set(id, updatedItem);
    return updatedItem;
  }

  async deleteCartItem(id: number): Promise<void> {
    if (!this.cartItems.has(id)) {
      throw new Error(`Cart item with ID ${id} not found`);
    }
    this.cartItems.delete(id);
  }

  async deleteCartItemsBySession(sessionId: number): Promise<void> {
    for (const [id, item] of this.cartItems.entries()) {
      if (item.cartSessionId === sessionId) {
        this.cartItems.delete(id);
      }
    }
  }
}

// Create and export a singleton instance
export const storage = new MemStorage();
