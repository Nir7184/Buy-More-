import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertContactMessageSchema, 
  insertStoreSchema, 
  insertProductSchema, 
  insertOrderSchema, 
  insertOrderItemSchema, 
  insertReviewSchema,
  insertCartSessionSchema,
  insertCartItemSchema 
} from "@shared/schema";
import { z } from "zod";
import { ZodError } from "zod-validation-error";

// Middleware to check if user is authenticated
const isAuthenticated = (req: any, res: any, next: any) => {
  if (req.session && req.session.userId) {
    return next();
  }
  return res.status(401).json({ message: "Unauthorized" });
};

// Middleware to check if user is a store owner
const isStoreOwner = async (req: any, res: any, next: any) => {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  const user = await storage.getUser(req.session.userId);
  if (!user || user.userType !== "store_owner") {
    return res.status(403).json({ message: "Forbidden: Store owner access required" });
  }

  return next();
};

// Middleware to check if user is a customer
const isCustomer = async (req: any, res: any, next: any) => {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  const user = await storage.getUser(req.session.userId);
  if (!user || user.userType !== "customer") {
    return res.status(403).json({ message: "Forbidden: Customer access required" });
  }

  return next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication Routes
  app.post("/api/auth/signup", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }

      // Create user
      const newUser = await storage.createUser(userData);

      // If user is a store owner, create their store
      if (userData.userType === "store_owner" && req.body.storeDetails) {
        const storeData = {
          ...req.body.storeDetails,
          ownerId: newUser.id,
        };
        
        const storeValidation = insertStoreSchema.parse(storeData);
        await storage.createStore(storeValidation);
      }

      // Set session
      if (req.session) {
        req.session.userId = newUser.id;
      }

      // Remove password from response
      const { password, ...userWithoutPassword } = newUser;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Signup error:", error);
      res.status(500).json({ message: "Failed to create account" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      // Validate request
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }

      // Check if user exists
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Check password
      if (user.password !== password) { // In a real app, use proper hashing
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Set session
      if (req.session) {
        req.session.userId = user.id;
      }

      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Failed to log in" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    if (req.session) {
      req.session.destroy((err) => {
        if (err) {
          return res.status(500).json({ message: "Failed to log out" });
        }
        res.json({ message: "Logged out successfully" });
      });
    } else {
      res.json({ message: "Not logged in" });
    }
  });

  app.get("/api/auth/me", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Auth check error:", error);
      res.status(500).json({ message: "Failed to get user information" });
    }
  });

  // Store Routes
  app.get("/api/stores", async (req, res) => {
    try {
      const stores = await storage.getAllStores();
      res.json(stores);
    } catch (error) {
      console.error("Get stores error:", error);
      res.status(500).json({ message: "Failed to get stores" });
    }
  });

  app.get("/api/stores/featured", async (req, res) => {
    try {
      const stores = await storage.getFeaturedStores();
      res.json(stores);
    } catch (error) {
      console.error("Get featured stores error:", error);
      res.status(500).json({ message: "Failed to get featured stores" });
    }
  });

  app.get("/api/stores/:id", async (req, res) => {
    try {
      const storeId = parseInt(req.params.id);
      if (isNaN(storeId)) {
        return res.status(400).json({ message: "Invalid store ID" });
      }

      const store = await storage.getStore(storeId);
      if (!store) {
        return res.status(404).json({ message: "Store not found" });
      }
      
      res.json(store);
    } catch (error) {
      console.error("Get store error:", error);
      res.status(500).json({ message: "Failed to get store" });
    }
  });

  app.get("/api/stores/:id/products", async (req, res) => {
    try {
      const storeId = parseInt(req.params.id);
      if (isNaN(storeId)) {
        return res.status(400).json({ message: "Invalid store ID" });
      }

      const products = await storage.getProductsByStore(storeId);
      res.json(products);
    } catch (error) {
      console.error("Get store products error:", error);
      res.status(500).json({ message: "Failed to get products" });
    }
  });

  app.get("/api/stores/owner", isStoreOwner, async (req, res) => {
    try {
      const store = await storage.getStoreByOwner(req.session.userId);
      if (!store) {
        return res.status(404).json({ message: "Store not found" });
      }
      
      res.json(store);
    } catch (error) {
      console.error("Get owner store error:", error);
      res.status(500).json({ message: "Failed to get store" });
    }
  });

  app.get("/api/stores/owner/products", isStoreOwner, async (req, res) => {
    try {
      const store = await storage.getStoreByOwner(req.session.userId);
      if (!store) {
        return res.status(404).json({ message: "Store not found" });
      }
      
      const products = await storage.getProductsByStore(store.id);
      res.json(products);
    } catch (error) {
      console.error("Get owner products error:", error);
      res.status(500).json({ message: "Failed to get products" });
    }
  });

  app.get("/api/stores/owner/orders", isStoreOwner, async (req, res) => {
    try {
      const store = await storage.getStoreByOwner(req.session.userId);
      if (!store) {
        return res.status(404).json({ message: "Store not found" });
      }
      
      const orders = await storage.getOrdersByStore(store.id);
      
      // Add customer info and product details to each order
      const ordersWithDetails = await Promise.all(orders.map(async (order) => {
        const customer = await storage.getUser(order.userId);
        const orderItems = await storage.getOrderItemsByOrder(order.id);
        
        // Get product details for each order item
        const itemsWithProducts = await Promise.all(orderItems.map(async (item) => {
          const product = await storage.getProduct(item.productId);
          return { ...item, product };
        }));
        
        return { 
          ...order, 
          items: itemsWithProducts,
          customer: customer ? {
            fullName: customer.fullName,
            phone: customer.phone || "Not provided"
          } : {
            fullName: "Unknown",
            phone: "Not provided"
          }
        };
      }));
      
      res.json(ordersWithDetails);
    } catch (error) {
      console.error("Get store orders error:", error);
      res.status(500).json({ message: "Failed to get orders" });
    }
  });

  // Product Routes
  app.post("/api/products", isStoreOwner, async (req, res) => {
    try {
      const store = await storage.getStoreByOwner(req.session.userId);
      if (!store) {
        return res.status(404).json({ message: "Store not found" });
      }
      
      const productData = {
        ...req.body,
        storeId: store.id
      };
      
      const validatedData = insertProductSchema.parse(productData);
      const newProduct = await storage.createProduct(validatedData);
      
      res.status(201).json(newProduct);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Create product error:", error);
      res.status(500).json({ message: "Failed to create product" });
    }
  });

  app.patch("/api/products/:id", isStoreOwner, async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      if (isNaN(productId)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }
      
      const product = await storage.getProduct(productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      const store = await storage.getStoreByOwner(req.session.userId);
      if (!store || product.storeId !== store.id) {
        return res.status(403).json({ message: "You do not have permission to update this product" });
      }
      
      const updatedProduct = await storage.updateProduct(productId, req.body);
      res.json(updatedProduct);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Update product error:", error);
      res.status(500).json({ message: "Failed to update product" });
    }
  });

  app.delete("/api/products/:id", isStoreOwner, async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      if (isNaN(productId)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }
      
      const product = await storage.getProduct(productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      const store = await storage.getStoreByOwner(req.session.userId);
      if (!store || product.storeId !== store.id) {
        return res.status(403).json({ message: "You do not have permission to delete this product" });
      }
      
      await storage.deleteProduct(productId);
      res.json({ message: "Product deleted successfully" });
    } catch (error) {
      console.error("Delete product error:", error);
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  // Order Routes
  app.post("/api/orders", isAuthenticated, async (req, res) => {
    try {
      const orderData = {
        ...req.body,
        userId: req.session.userId
      };
      
      const validatedData = insertOrderSchema.parse(orderData);
      
      // Check if the store exists
      const store = await storage.getStore(validatedData.storeId);
      if (!store) {
        return res.status(404).json({ message: "Store not found" });
      }
      
      // Create the order
      const newOrder = await storage.createOrder(validatedData);
      
      // Add order items
      if (req.body.items && Array.isArray(req.body.items)) {
        for (const item of req.body.items) {
          const orderItemData = {
            orderId: newOrder.id,
            productId: item.productId,
            quantity: item.quantity,
            price: item.price
          };
          
          await storage.createOrderItem(orderItemData);
        }
      }
      
      res.status(201).json(newOrder);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Create order error:", error);
      res.status(500).json({ message: "Failed to create order" });
    }
  });

  app.get("/api/orders/user", isAuthenticated, async (req, res) => {
    try {
      const orders = await storage.getOrdersByUser(req.session.userId);
      
      // Add product details to each order
      const ordersWithItems = await Promise.all(orders.map(async (order) => {
        const orderItems = await storage.getOrderItemsByOrder(order.id);
        
        // Get product details for each order item
        const itemsWithProducts = await Promise.all(orderItems.map(async (item) => {
          const product = await storage.getProduct(item.productId);
          return { ...item, product };
        }));
        
        return { ...order, items: itemsWithProducts };
      }));
      
      res.json(ordersWithItems);
    } catch (error) {
      console.error("Get user orders error:", error);
      res.status(500).json({ message: "Failed to get orders" });
    }
  });

  app.patch("/api/orders/:id/status", isStoreOwner, async (req, res) => {
    try {
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }
      
      const { status } = req.body;
      if (!status || !["pending", "ready", "completed", "cancelled"].includes(status)) {
        return res.status(400).json({ message: "Invalid status value" });
      }
      
      const order = await storage.getOrder(orderId);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      // Check if the store belongs to the user
      const store = await storage.getStoreByOwner(req.session.userId);
      if (!store || order.storeId !== store.id) {
        return res.status(403).json({ message: "You do not have permission to update this order" });
      }
      
      const updatedOrder = await storage.updateOrder(orderId, { status });
      res.json(updatedOrder);
    } catch (error) {
      console.error("Update order status error:", error);
      res.status(500).json({ message: "Failed to update order status" });
    }
  });

  app.patch("/api/orders/:id/cancel", isAuthenticated, async (req, res) => {
    try {
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }
      
      const order = await storage.getOrder(orderId);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      // Check if the order belongs to the user
      if (order.userId !== req.session.userId) {
        return res.status(403).json({ message: "You do not have permission to cancel this order" });
      }
      
      // Check if the order is in a state that can be cancelled
      if (order.status !== "pending") {
        return res.status(400).json({ message: "Only pending orders can be cancelled" });
      }
      
      const updatedOrder = await storage.updateOrder(orderId, { status: "cancelled" });
      res.json(updatedOrder);
    } catch (error) {
      console.error("Cancel order error:", error);
      res.status(500).json({ message: "Failed to cancel order" });
    }
  });

  app.patch("/api/orders/:id/reschedule", isAuthenticated, async (req, res) => {
    try {
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }
      
      const { pickupTime } = req.body;
      if (!pickupTime) {
        return res.status(400).json({ message: "Pickup time is required" });
      }
      
      const order = await storage.getOrder(orderId);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      // Check if the order belongs to the user
      if (order.userId !== req.session.userId) {
        return res.status(403).json({ message: "You do not have permission to reschedule this order" });
      }
      
      // Check if the order is in a state that can be rescheduled
      if (order.status !== "pending") {
        return res.status(400).json({ message: "Only pending orders can be rescheduled" });
      }
      
      const updatedOrder = await storage.updateOrder(orderId, { pickupTime: new Date(pickupTime) });
      res.json(updatedOrder);
    } catch (error) {
      console.error("Reschedule order error:", error);
      res.status(500).json({ message: "Failed to reschedule order" });
    }
  });

  // Contact Routes
  app.post("/api/contact", async (req, res) => {
    try {
      const contactData = insertContactMessageSchema.parse(req.body);
      const newMessage = await storage.createContactMessage(contactData);
      res.status(201).json({ message: "Message sent successfully", id: newMessage.id });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Contact message error:", error);
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  // Review Routes
  app.post("/api/reviews", isAuthenticated, async (req, res) => {
    try {
      const reviewData = {
        ...req.body,
        userId: req.session.userId
      };
      
      const validatedData = insertReviewSchema.parse(reviewData);
      
      // Check if the store exists
      const store = await storage.getStore(validatedData.storeId);
      if (!store) {
        return res.status(404).json({ message: "Store not found" });
      }
      
      // Check if user has already reviewed this store
      const existingReview = await storage.getReviewByUserAndStore(req.session.userId, validatedData.storeId);
      if (existingReview) {
        return res.status(400).json({ message: "You have already reviewed this store" });
      }
      
      // Create the review
      const newReview = await storage.createReview(validatedData);
      
      // Update store rating
      const storeReviews = await storage.getReviewsByStore(validatedData.storeId);
      const totalRating = storeReviews.reduce((sum, review) => sum + review.rating, 0);
      const averageRating = totalRating / storeReviews.length;
      
      await storage.updateStore(validatedData.storeId, {
        rating: averageRating,
        reviewCount: storeReviews.length
      });
      
      res.status(201).json(newReview);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Create review error:", error);
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  app.get("/api/reviews/store/:id", async (req, res) => {
    try {
      const storeId = parseInt(req.params.id);
      if (isNaN(storeId)) {
        return res.status(400).json({ message: "Invalid store ID" });
      }
      
      const reviews = await storage.getReviewsByStore(storeId);
      
      // Add user info to each review
      const reviewsWithUserInfo = await Promise.all(reviews.map(async (review) => {
        const user = await storage.getUser(review.userId);
        return {
          ...review,
          userName: user ? user.fullName : "Anonymous"
        };
      }));
      
      res.json(reviewsWithUserInfo);
    } catch (error) {
      console.error("Get store reviews error:", error);
      res.status(500).json({ message: "Failed to get reviews" });
    }
  });

  // Cart Routes
  app.post("/api/cart", async (req, res) => {
    try {
      const { sessionId, storeId } = req.body;
      
      if (!sessionId || !storeId) {
        return res.status(400).json({ message: "Session ID and store ID are required" });
      }
      
      // Check if the store exists
      const store = await storage.getStore(storeId);
      if (!store) {
        return res.status(404).json({ message: "Store not found" });
      }
      
      // Create or update cart session
      let cartSession = await storage.getCartSessionBySessionId(sessionId);
      
      if (cartSession) {
        // If cart exists but for a different store, return error
        if (cartSession.storeId !== storeId) {
          return res.status(400).json({ 
            message: "Cart already contains items from a different store",
            existingStoreId: cartSession.storeId
          });
        }
        
        // Update updated time
        await storage.updateCartSession(cartSession.id, { updatedAt: new Date() });
      } else {
        // Create new cart session
        const cartData = {
          sessionId,
          storeId,
          userId: req.session?.userId || null
        };
        
        cartSession = await storage.createCartSession(cartData);
      }
      
      res.status(201).json(cartSession);
    } catch (error) {
      console.error("Create cart error:", error);
      res.status(500).json({ message: "Failed to create cart" });
    }
  });

  app.post("/api/cart/items", async (req, res) => {
    try {
      const { sessionId, productId, quantity } = req.body;
      
      if (!sessionId || !productId || !quantity) {
        return res.status(400).json({ message: "Session ID, product ID, and quantity are required" });
      }
      
      // Get cart session
      const cartSession = await storage.getCartSessionBySessionId(sessionId);
      if (!cartSession) {
        return res.status(404).json({ message: "Cart not found" });
      }
      
      // Check if product belongs to the store in the cart
      const product = await storage.getProduct(productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      if (product.storeId !== cartSession.storeId) {
        return res.status(400).json({ message: "Product does not belong to the store in the cart" });
      }
      
      // Check if item already exists in cart
      const existingItem = await storage.getCartItemByProductAndSession(productId, cartSession.id);
      
      if (existingItem) {
        // Update quantity
        const updatedItem = await storage.updateCartItem(existingItem.id, { quantity });
        res.json(updatedItem);
      } else {
        // Add new item
        const cartItemData = {
          cartSessionId: cartSession.id,
          productId,
          quantity
        };
        
        const newItem = await storage.createCartItem(cartItemData);
        res.status(201).json(newItem);
      }
    } catch (error) {
      console.error("Add cart item error:", error);
      res.status(500).json({ message: "Failed to add item to cart" });
    }
  });

  app.get("/api/cart/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      
      // Get cart session
      const cartSession = await storage.getCartSessionBySessionId(sessionId);
      if (!cartSession) {
        return res.json({ 
          items: [], 
          storeId: null,
          store: null,
          total: 0
        });
      }
      
      // Get cart items
      const cartItems = await storage.getCartItemsBySession(cartSession.id);
      
      // Get product details for each item
      const itemsWithDetails = await Promise.all(cartItems.map(async (item) => {
        const product = await storage.getProduct(item.productId);
        return {
          ...item,
          product
        };
      }));
      
      // Get store details
      const store = await storage.getStore(cartSession.storeId);
      
      // Calculate total
      const total = itemsWithDetails.reduce((sum, item) => (
        sum + (item.product?.price || 0) * item.quantity
      ), 0);
      
      res.json({
        items: itemsWithDetails,
        storeId: cartSession.storeId,
        store,
        total
      });
    } catch (error) {
      console.error("Get cart error:", error);
      res.status(500).json({ message: "Failed to get cart" });
    }
  });

  app.delete("/api/cart/:sessionId/items/:itemId", async (req, res) => {
    try {
      const { sessionId, itemId } = req.params;
      
      // Get cart session
      const cartSession = await storage.getCartSessionBySessionId(sessionId);
      if (!cartSession) {
        return res.status(404).json({ message: "Cart not found" });
      }
      
      // Get cart item
      const cartItem = await storage.getCartItem(parseInt(itemId));
      if (!cartItem || cartItem.cartSessionId !== cartSession.id) {
        return res.status(404).json({ message: "Item not found in cart" });
      }
      
      // Delete cart item
      await storage.deleteCartItem(cartItem.id);
      
      // Check if cart is empty
      const remainingItems = await storage.getCartItemsBySession(cartSession.id);
      if (remainingItems.length === 0) {
        // Delete cart session if empty
        await storage.deleteCartSession(cartSession.id);
      }
      
      res.json({ message: "Item removed from cart" });
    } catch (error) {
      console.error("Remove cart item error:", error);
      res.status(500).json({ message: "Failed to remove item from cart" });
    }
  });

  app.delete("/api/cart/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      
      // Get cart session
      const cartSession = await storage.getCartSessionBySessionId(sessionId);
      if (!cartSession) {
        return res.status(404).json({ message: "Cart not found" });
      }
      
      // Delete all cart items
      await storage.deleteCartItemsBySession(cartSession.id);
      
      // Delete cart session
      await storage.deleteCartSession(cartSession.id);
      
      res.json({ message: "Cart cleared successfully" });
    } catch (error) {
      console.error("Clear cart error:", error);
      res.status(500).json({ message: "Failed to clear cart" });
    }
  });

  // Create and return HTTP server
  const httpServer = createServer(app);
  return httpServer;
}
